var log4js = require('log4js');
var logger = log4js.getLogger();
var chai = require("chai");
var chaiHttp = require("chai-http");
chai.use(chaiHttp);
proxy = 'http://185.46.212.97:9480';
chai.request.Request = chai.request.Test;
require('superagent-proxy')(chai.request);
const protractor = require('protractor');
const EC = protractor.ExpectedConditions;
const elements=require('../Elements_Contains/Elements.js');

var utils = function () {
  
  this.appInitialization = async function(url){
    try{
      browser.ignoreSynchronization = true;
      browser.get(url);
      browser.driver.manage().window().maximize();
      browser.waitForAngularEnabled(true);
      browser.manage().timeouts().implicitlyWait(5000);
    } catch(e){
      logger.error('Error while App Initializing' + e.message);
    }
  };

  this.readPropertyFile = async function(env, key) {
    const properties = PropertiesReader(`./test/testdata/${env}.properties`);
    return function(key) {
      const element = properties.get(key);
      return element;
    }
  };
  
  this.postMethod = async function (IP, PATH, BODY) {
    const expect = chai.expect;
    const chaiHttp1 = chai.request(IP);
    ///##########proxy settings for philips jenkins#############
   const response = chaiHttp1.post(PATH).proxy(proxy).send(BODY).set("Content-type","application/json").set("api-version", "1").set("accept", "application/json");
  // const response = chaiHttp1.post(PATH).send(BODY).set("Content-type","application/json").set("api-version", "1").set("accept", "application/json");
    return response;
  };

  this.getMethod = async function (IP, PATH, ACCESSTOKEN) { 
    const expect = chai.expect;
    const chaiHttp1 = chai.request(IP);
    ///##########proxy settings for philips jenkins#############
   const response = chaiHttp1.get(PATH).proxy(proxy).set("accept", "application/json").set("Content-type","application/json").set("authorization", ACCESSTOKEN);
  //   const response = chaiHttp1.get(PATH).set("accept", "application/json").set("Content-type","application/json").set("authorization", ACCESSTOKEN);
    return response;
  };

  this.getMethodWithoutAccessToken = async function (IP, PATH) { 
    const expect = chai.expect;
    const chaiHttp1 = chai.request(IP);
    ///##########proxy settings for philips jenkins#############
     const response = chaiHttp1.get(PATH).proxy(proxy);
  //const response = chaiHttp1.get(PATH);

    return response;
  };
  
this.clickAction = async function(element) {
    element.click();
  };

this.clearAction = async function(element) {
    element.clear();
  };

this.sendDataToTextBox = async function (element, value) {
    element.clear();
    element.sendKeys(value);
  };
this.getRandomInt = async function (min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
  };
this.searchPracticeInSearchBox = async function(practice_name){
    expect(regionCountryPracticesElements.searchBoxOfPractices.isPresent()).to.be.true;
    expect(regionCountryPracticesElements.searchBoxOfPractices.isEnabled()).to.be.true;
    await this.sendDataToTextBox(regionCountryPracticesElements.searchBoxOfPractices, practice_name);
  };

this.putMethod = async function (IP, PATH, BODY) {
    const expect = chai.expect;
    const chaiHttp1 = chai.request(IP);
    ///##########proxy settings for philips jenkins#############
   const response = chaiHttp1.put(PATH).proxy(proxy).send(BODY).set("Content-type","application/json").set("api-version", "1").set("accept", "application/json");
  // const response = chaiHttp1.put(PATH).send(BODY).set("Content-type","application/json").set("api-version", "1").set("accept", "application/json");
    return response;
  };
  
this.getMethodWithoutHeader = async function (IP, PATH, ACCESSTOKEN) {
    const expect = chai.expect;
    const chaiHttp1 = chai.request(IP);
   //const response = chaiHttp1.get(PATH);
    ///##########proxy settings for philips jenkins#############
  const response = chaiHttp1.get(PATH).proxy(proxy);
    return response;
  };
  
this.searchDeviceInSearchBox = async function(device_name){
    expect(viewSiteNetworkElements.searchBoxOfDevices.isPresent()).to.be.true;
    expect(viewSiteNetworkElements.searchBoxOfDevices.isEnabled()).to.be.true;
    this.sendDataToTextBox(viewSiteNetworkElements.searchBoxOfDevices, device_name);
  };

this.getTextFromTextBox = async function(element){
    const text=await element.getText()
    return text;
  };

this.checkIfElementPresent = async function(element){
    const result=await element.isPresent();
    return result;
  };

this.getTitleOfPage = async function(){
    const text=await browser.getTitle();
    return text;
  };

this.checkIfElementEnabled = async function(element){
    const result=await element.isEnabled();
    return result;
  };

this.getCurrentUrl = async function(){
    const url=await browser.getCurrentUrl();
    return url;
  };
  
this.switchToNewWindow = async function(){
    browser.executeScript('window.open()');
    browser.sleep(2000);
    browser.getAllWindowHandles().then(function (handles) {
      const newWindowHandle = handles[1];
      browser.switchTo().window(newWindowHandle);
      });
  };
  
this.postMethodWithSpecificHeader = async function (IP, PATH, BODY) {
    const expect = chai.expect;
    const chaiHttp1 = chai.request(IP);
  //const response = await chaiHttp1.post(PATH).set("Content-type","application/json").set("api-version", "1").send(BODY);
///##########proxy settings for philips jenkins#############
    const response = await chaiHttp1.post(PATH).proxy(proxy).send(BODY).set("Content-type","application/json").set("api-version", "1");
    return response;
  };
  
this.getMethodWithSpecificToken = async function (IP, PATH, TOKEN) {
    const expect = chai.expect;
    const chaiHttp1 = chai.request(IP);
  // const response = chaiHttp1.get(PATH).set("x-vault-token", TOKEN);
    ///##########proxy settings for philips jenkins#############
   const response = chaiHttp1.get(PATH).proxy(proxy).set("x-vault-token", TOKEN);
    return response;
  };
  
this.postMethodWithToken = async function (IP, PATH, BODY, TOKEN) {
    const expect = chai.expect;
    const chaiHttp1 = chai.request(IP);
    //            const response = chaiHttp1.post(PATH).send(BODY).set("Content-type","application/json").set("api-version", "1").set("accept", "application/json").set("Authorization", "Bearer"+" "+TOKEN).set('x-forwarded-proto','proto');
    ///##########proxy settings for philips jenkins#############
                  const response = chaiHttp1.post(PATH).proxy(proxy).send(BODY).set("Content-type","application/json").set("api-version", "1").set("accept", "application/json").set("Authorization", "Bearer"+" "+TOKEN).set('x-forwarded-proto','proto');
    return response;
  };    

this.getMethodWithToken = async function (IP, PATH, TOKEN) {
    const expect = chai.expect;
    const chaiHttp1 = chai.request(IP);
    ///##########proxy settings for philips jenkins#############
    const response = chaiHttp1.get(PATH).proxy(proxy).set("Authorization", "Bearer"+" "+TOKEN);
    //const response = chaiHttp1.get(PATH).set("Authorization", "Bearer"+" "+TOKEN);
    return response;
  }; 
  
this.putMethodWithToken = async function (IP, PATH, BODY, TOKEN) {
    const expect = chai.expect;
    const chaiHttp1 = chai.request(IP);
    ///##########proxy settings for philips jenkins#############
const response = chaiHttp1.put(PATH).proxy(proxy).set("Content-type","application/json").set("api-version", "1").set("accept", "application/json").set("Authorization", "Bearer"+" "+TOKEN).set('x-forwarded-proto','https').send(BODY);
  //const response = chaiHttp1.put(PATH).set("Content-type","application/json").set("api-version", "1").set("Accept", "application/json").set("Authorization", "Bearer"+" "+TOKEN).set('x-forwarded-proto','https').send(BODY);
    return response;
  };
this.currentdateAndtime= async function(){
    var now = new Date().toISOString().slice(0,19);
    var splittedvalue=now.split("T");
    var currentDateAndtime=splittedvalue[0]+' '+splittedvalue[1];
    return currentDateAndtime;
    };
this.setTimeout=async function(){
   var {setDefaultTimeout} = require('cucumber');
   setDefaultTimeout(200 * 1000);
   };
this.currentdate=async function(){
    var dateTime = new Date();
    var dd = dateTime.getDate();
    return dd;
};
this.endDate= async function(){
    var now = new Date().toISOString().slice(0,19);
    return now+"Z";
    };
this.startDate = function(){
function addZero(i) {
            if (i < 10) {
                            i = "0" + i;
                         }
                           return i;
                      };
var dateTimeFormat = new Date();
var yyyy = dateTimeFormat.getFullYear();
var mm = addZero(dateTimeFormat.getMonth()+1);
var dd = addZero(dateTimeFormat.getDate()-1);
var h = addZero(dateTimeFormat.getUTCHours());
var m = addZero(dateTimeFormat.getUTCMinutes());
var s = addZero(dateTimeFormat.getUTCSeconds());
global.date=dateTimeFormat.getDate()-1;
if(global.date==0)
{
  global.date=1;

}
var CurrentDateAndTime = yyyy+'-'+mm+'-'+dd+'T'+h+':'+m+':'+s+'Z';
return CurrentDateAndTime;
   };
this.postMethodwithcontenttypeHeader= async function(IP ,PATH,BODY){
  const expect = chai.expect;
const chaiHttp1 = chai.request(IP);
// console.log("99999999999999999999999999999")
// "d4b5ca6386d6413e80a", "n5.-2nY2!!54-@FS"
//console.log(global.bootstarpClientId)
//console.log(global.bootstrapClientSecret)
///##########proxy settings for philips jenkins#############/
 // const response = await chaiHttp1.post(PATH).proxy(proxy).send(BODY);
//const response = await chaiHttp1.post(PATH).set('content-type', 'application/x-www-form-urlencoded').set("Authorization", "Basic NGViNzg1MDU3Y2I5NDBlM2JjMzpRWDlQNDdGNmghY3drREA3").auth(global.bootstarpClientId, global.bootstrapClientSecret).send(BODY);
const response = await chaiHttp1.post(PATH).proxy(proxy).set('content-type', 'application/x-www-form-urlencoded').set("Authorization", "Basic NGViNzg1MDU3Y2I5NDBlM2JjMzpRWDlQNDdGNmghY3drREA3").auth(global.bootstarpClientId, global.bootstrapClientSecret).send(BODY);
// console.log(response)
return response
};

this.postMethodwithHeaders = async function (IP, PATH, ACCESSTOKEN, BODY) {
const expect = chai.expect;
const chaiHttp1 = chai.request(IP);
///##########proxy settings for philips jenkins#############
  const response = await chaiHttp1.post(PATH).proxy(proxy).set('content-type', 'application/json').set('api-version','1').set('Accept','application/json').set("authorization", ACCESSTOKEN).set('x-forwarded-proto','https').send(BODY);
//const response = await chaiHttp1.post(PATH).set('content-type', 'application/json').set('api-version','1').set('Accept','application/json').set("authorization", ACCESSTOKEN).set('x-forwarded-proto','https').send(BODY);
return response;
};
this.wait_tillVisble = async function(webelement) {
    browser.wait(EC.presenceOf(webelement),5000);
};
this.getbrowserName=async function(){

   const caps = await browser.driver.getCapabilities();
    browser.browserName = caps.get('browserName');
return browser.browserName;

};
this.postMethodWithAuth = async function (IP, PATH, BODY) {
  const expect = chai.expect;
  const chaiHttp1 = chai.request(IP);
//const response = await chaiHttp1.post(PATH).set("Content-type","application/x-www-form-urlencoded").set("api-version", "2").auth(global.clientId, clientSecretId).send(BODY);
///##########proxy settings for philips jenkins#############
const response =await chaiHttp1.post(PATH).proxy(proxy).set("Content-type","application/x-www-form-urlencoded").set("api-version", "2").auth(global.clientId, clientSecretId).set("Authorization", "Basic Zjk4OTQxZWJjZmFkNDE4NTgyMDpPSS4wMndGT3MuQGQyWGhs").send(BODY);
// const response =await chaiHttp1.post(PATH).set("Content-type","application/x-www-form-urlencoded").set("api-version", "2").auth(global.clientId, clientSecretId).set("Authorization", "Basic Zjk4OTQxZWJjZmFkNDE4NTgyMDpPSS4wMndGT3MuQGQyWGhs").send(BODY);
  return response;
};


    
};
module.exports = new utils();
