var log4js = require('log4js'); 
var logger = log4js.getLogger();
var chai=require('chai');
chaiHttp = require('chai-http');
chai.use(chaiHttp);
const protractor = require('protractor');
const EC = protractor.ExpectedConditions;
const elements=require('../Elements_Contains/Elements.js');
const utils = require('./utils.js');
const data = require('../../Test_Data/global_input.json');

var login = function () {
    
    this.getVaultToken = async function (){
        const expect = chai.expect;
        var vaultTokenCreation = JSON.stringify(data.Vault_Token_Creation_Payload);
       
        try{

            await utils.postMethodWithSpecificHeader(data["Vault_Token_Creation_IP"], data["Vault_Token_Creation_Path"], JSON.parse(vaultTokenCreation)).then(function(response){
            global.VaultToken = response.body.auth.client_token;
                });
                } catch(e){
                    logger.error('Error while Vault Token' + e.message);
                    expect.fail("Error while Vault Token" + e.message);
                }
    };
                    
    this.getDataFromVault = async function (){
        const expect = chai.expect;
        try{
            await utils.getMethodWithSpecificToken(data["Vault_Get_Credential_IP"], data["Vault_Get_Credential_Path"], global.VaultToken).then(function(response){

            global.ServiceUIUser = response.body.data.Service_UI_User;
            global.ServiceUIPassword = response.body.data.Service_UI_Password;
            global.ServiceUIFSEUser = response.body.data.Service_UI_FSE_User;
            global.ServiceUIFSEPassword = response.body.data.Service_UI_FSE_Password;
            global.ServiceUITSEUser = response.body.data.Service_UI_TSE_User;
            global.ServiceUITSEPassword = response.body.data.Service_UI_TSE_Password;
            global.ServiceUITsaUser = response.body.data.Service_UI_Tsa_User;
            global.ServiceUInewTSEUser = response.body.data.Service_UI_new_tse_User;
            global.ServiceUIdosUser = response.body.data.Service_UI_dos_User;

            global.bootstrapClientSecret=response.body.data.bootstrapClientSecret;
            global.bootstarpClientId=response.body.data.bootstarpClientId;
            global.AuthTokenCreationPayload = JSON.stringify(response.body.data.Auth_Token_creation_payload);
            //global.DeviceTokenpayload=JSON.stringify(response.body.data.device_token_payload);
            global.dbuser=response.body.data.service_app_db_user;
            global.dbpassword=response.body.data.service_app_db_password;
            global.deviceClientId=response.body.data.oauthClientId;
            global.deviceClientSecret=response.body.data.oauthClientSecret;
            global.deviceLoginId=response.body.data.listdeviceLoginId;
            global.devicePwd=response.body.data.listDevicesPwd;
            global.deviceLoginId2=response.body.data.listdeviceLoginId2;
            global.devicePwd2=response.body.data.listDevicesPwd2;
            });
            } catch(e){
                logger.error('Error while getting Vault Data' + e.message);
                expect.fail("Error while Vault data" + e.message);
                
                }
    };  
    
    this.setUserInUserNameField = async function(element, user){
        await utils.sendDataToTextBox(element, user);
      };
    
      this.setPasswordInPasswordField = async function(element, password){
        await utils.sendDataToTextBox(element, password);
      };
      this.accesstokenfunc= async function(){
        const expect = chai.expect;
  
        try{
          this.getVaultToken();
          this.getDataFromVault();
          var tokenCreation = JSON.stringify(global.AuthTokenCreationPayload);
          await utils.postMethod(data["access_token_IP"], data["access_token_creation_Path"], JSON.parse(tokenCreation)).then(function(response){
          global.Access = response.body.access_token;
          global.response = response;
        });
      } catch(e){
        console.log('Error while App Initializing' + e.message);
        expect.fail("Error while access Token" + e.message);
      };
          
      };
            
     this.devicetokenfunc= async function(){      
            try{
                    const expect = chai.expect;
                    this.getVaultToken();
                    this.getDataFromVault();
                
                const payload=
                { 
                    "grant_type":"password",
                    "username":global.LoginID,
                    "password":global.password  
                }

        const formBody = Object.entries(payload).map(([key, value]) => encodeURIComponent(key) + '=' + encodeURIComponent(value)).join('&')
        
        await utils.postMethodWithAuth(data["device_token_creation_ip"], data["device_token_creation_path"],formBody).then(function(response){
            const st=response.status;  
            global.status=JSON.stringify(st)
            global.devicetoken = response.body.access_token;
            
                 });
                
                 } catch(e){
                       logger.error('Error while App Initializing' + e.message);
                       expect.fail("Error while device Token" + e.message);
                     }
                
              
          };

      this.bootstarptokenfunc= async function(){
        const expect = chai.expect;
  
        try{
    
            const expect = chai.expect;
            this.getVaultToken();
          this.getDataFromVault();
          const tokenPayLoad={
            "bootstarpClientId":global.bootstarpClientId,
            "bootstrapClntSct":global.bootstrapClientSecret
                                }
await utils.postMethodwithcontenttypeHeader(data["bootstrap_token_creation_ip"], data["bootstrap_token_creation_path"],tokenPayLoad).then(function(response){
const st=response.status;
  
        global.status=JSON.stringify(st)
        global.bootstarp=response.text;
             });
            
             } catch(e){
                   logger.error('Error while App Initializing' + e.message);
                   expect.fail("Error while bootstrap Token" + e.message);
                 }
            
          
      };
};
module.exports = new login();
