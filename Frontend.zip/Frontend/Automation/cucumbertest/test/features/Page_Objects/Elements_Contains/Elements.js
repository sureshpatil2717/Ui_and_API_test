const { element } = require("protractor");

const Elements = function () {

//login_Elements
    this.username = element(by.id('username'));
    this.password = element(by.id('password'));
    this.signin = element(by.id('loginButton'));
    this.invalid_email =element(by.id('usernameInvalidErrorMessage'));
    this.invalid_password=element(by.id('passwordInvalidErrorMessage'));
    this.check_your_username_and_password=element(by.xpath('//small[text()="Please check your username and password"]'));
    this.email_address_cannot_be_blank=element(by.xpath('//small[text()=" Email address cannot be blank "]'));
    this.email_address_cannot_be_blank=element(by.id('usernameErrorMessage'));
    this.password_cannot_be_blank=element(by.xpath('//small[text()=" Password cannot be blank "]'));

   // region_country_practices_Elements
   
        this.Select_Region = element(by.xpath("//*[(@name='regionList')]"));
        this.Select_Country = element(by.xpath("//*[(@name='countryList')]"));
        this.Name = element(by.xpath("//*[contains(text(),'Name')]"));
        this.PracticeId = element(by.xpath("//*[contains(text(),'Practice Id ')]"));
        this.Practicetab = element(by.linkText("Practices"));
        this.PAM = element(by.xpath("//*[contains(text(),'PAM ')]"));
        this.email = element(by.xpath("//*[contains(text(),' Email ')]"));
        this.ORA_Sync_Enabled = element(by.xpath("//*[contains(text(),'ORA Sync Enabled')]"));
        this.region_header = element(by.xpath('//*[text()=" Region "]'));
        this.Status=element(by.xpath("//*[contains(text(),' Status ')]"));
        this.View_More = element(by.xpath("//*[contains(text(),'View More')]"));
        this.listedRegions = element.all(by.xpath('//*[(@name="regionList")]/option'));
        this.listedCountries = element.all(by.xpath('//*[(@name="countryList")]/option'));
        this.regionAndCountry = element(by.xpath('//*[@class="available-items"]'));
        this.searchBoxOfPractices = element(by.id('searchPracticeKey'));
        this.nextButtonForPracticesPaginations = element(by.xpath('//*[@class="paginate_button next"]'));
        this.previousButtonForPracticesPaginations = element(by.xpath('//*[@class="paginate_button previous"]'));
        this.selectedRegionDropdown = element(by.xpath('//*[@class="ngx-dropdown-button"]'));
        this.nonConfigureSpecificPractice = element(by.linkText('Julia eye clinic'));
        this.viewSiteNetworkConfiguredPractice = element(by.linkText('Anah Clininc'));
        this.devicesConfiguredPractice = element(by.linkText('Dynamo'));
        this.logMessageConfiguredPractice = element(by.linkText('Alan Eye Clinic'));
        this.TSEConfiguredPractice = element(by.linkText('Eye care clinic'));
        this.fseconfigure=element(by.linkText('fseconfigure'));
        this.practice_title=element(by.id('practiceListScreenTitle'));
        //this.menu=element(by.xpath('//*[@class="header-men-nav"]'));
       //this.signout=element(by.xpath("//@id='logoutEle']"));
  //this.signout=element(by.xpath('//*[@class="font-weight-normal m-2" and text()="SignOut"]'));
   this.menu=element(by.xpath("//*[@class='header-men-nav']//img[1]"));
       this.signout=element(by.xpath('//*[@id="logoutID"]'));
       this.cancel=element(by.id('dhs-sidebarmenu-close'));
       this.Access_denied_You_dont_have_permission_for_view_site_network=element(by.xpath('//div[@class="alert alert-danger ng-star-inserted"]//strong'));
       this.Access_Denied=element(by.xpath('//div[@class="alert alert-danger ng-star-inserted"]//strong'));
       this.search=element(by.xpath('//*[@id="searchPracticeKey"]'));
       this.Anah_Clininc =element(by.linkText('Anah Clininc'));
       this.Eye_care_clinic=element(by.linkText('Eye care clinic'));
       this.LangOneFive=element(by.linkText('LangOneFive'));
       this.LangOneThree=element(by.linkText('LangOneThree'));
       this.device_details=element(by.linkText('device details'));
       this.TestingTsa_Feature_link=element(by.linkText('TestingTsa Feature'));
       this.fseconfig_practice_link=element(by.linkText('fseconfig practice'));
       this.tseconfig_practice_link=element(by.linkText("tseconfig practice"));
       this.listDevices_practice=element(by.linkText("listDevices practice"));
       this.facility_Management=element(by.linkText('facility Management'));
       this.facility_link=element(by.xpath("(//a[@id='breadcrumbs1'])[3]"));
       this.pagination_practice_link=element(by.linkText('pagination practice'));
       this.pagination_facility=element(by.linkText('pagination facility'));
       this.pagination_test=element(by.linkText('pagination test'));
       this.TestPracticeAlcon_link=element(by.linkText("TestPracticeAlcon"));
       this.usafacilityDorris_link=element(by.linkText("Dorris"));
       this.svcgtwyci_link=element(by.linkText("svcgtwyci"));
       this.configureSitePractic_link=element(by.linkText('configureSitePractic'));
       this.configureSiteFacilit=element(by.linkText("configureSiteFacilit"));
       this.Greys_hospital_link=element(by.linkText('Greys hospital'));
       this.Albert_Eye_Clinic_link=element(by.linkText('Albert Eye Clini'));
       this.Alaska_caree_Test_link=element(by.linkText('Alaska caree Test'));
       this.tseview_practices=element(by.linkText('tseview practice'));
       this.manage_practices=element(by.linkText('managePractice'));
       this.device_details_practice_id=element(by.xpath('//*[text()="dfdafb26-c435-4681-a94b-d1ab110b9875"]'))
       this.configuration_practice=element(by.linkText('configurationpractic'));
    //    this.practice_Create_Practice_button=element(by.id('dhspracticelist-createpractice'));
         this.Greys_hospital=element(by.linkText('Greys hospital'));
         this.Alaska_caree_Test=element(by.linkText('Alaska caree Test'));
         this.Alaska_caree_Test_practice=element(by.xpath('//*[text()="839fa6a4-da9a-4e0c-8db0-45e6f9261ae5"]'));
         this.Greys_hospital_practice=element(by.xpath('//*[text()="b24045fe-e090-4449-8858-15ed6536c617"]'));
       this.SiteNetwork=element(by.xpath('//div[@class="td-ellipsis" and @_ngcontent-c3]/a[@href="javascript:"]'));
    this.practiceId_value=element(by.xpath('//table/tbody/tr[1]/td[2]'));
    this.practicename_value=element(by.xpath('//table/tbody/tr[1]/td[1]'));
    // this.return_practice=element(by.xpath('//*[@id="breadcrumbs1" and text()="Practices"]'));
    this.Region_value=element(by.xpath('//table/tbody/tr[1]/td[6]'));

    //createSiteNetwork_Elements

    this.edgeId=element(by.xpath("//*[@ng-reflect-name='edgeId']"));
    this.edgeId_label=element(by.xpath('//label[text()=" Edge Id "]'));
    this.edgeId_cannot_be_blank=element(by.xpath('//*[contains(text(),"Edge ID cannot be blank")]'));
    this.edgeId_check_pattern=element(by.xpath('//*[contains(text(),"Edge ID should match the pattern")]'));
    this.edgeId_already_exists=element(by.xpath('//*[contains(text(),"EdgeId already exists")]'));
    //this.edgeId_check_pattern=element(by.id("EdgeIDErrorMessage" and contains(text(),"Edge ID should match the pattern")]'));
    this.ip_address=element(by.xpath("//*[@ng-reflect-name ='ipAddress']"));
    this.ip_Address_Should_Match_The_Pattern=element(by.xpath('//*[@id = "DevicePatternRequiredErrorMessage" and contains(text()," IP Address Should match the pattern")]'));
    this.device_serial_number=element(by.xpath("//*[@formcontrolname='deviceSerialNumber']"));
    this.deviceManufacturer=element(by.xpath("//*[@formcontrolname='deviceManufacturer']"));
    this.device_serial_number_should_be_valid_pattern=element(by.id('DeviceSerialNumberPattern'));
    this.port_number=element(by.xpath('//*[@formcontrolname="port"]'));
    this.port_number_should_be_valid_pattern=element(by.id('PortErrorMessage'));
    this.device_version=element(by.xpath('//*[@formcontrolname="version"]'));
    // this.device_version_should_match_the_pattern=element(by.xpath('//*[@id = "DevicePatternRequiredErrorMessage" and contains(text(),"Device Version should match the pattern")]'));
    this.add_gateway=element(by.xpath("//*[text()='ADD GATEWAY']"));
    this.add_gatewayDetails=element(by.xpath("//*[text()='ADD GATEWAY DETAILS']"));
    this.DICOM=element(by.xpath('//*[text()="DICOM"]'));
    this.gateway_ip_address=element(by.xpath('//*[text()="123.4.5.6"]'));
    this.IOLMaster500QA=element(by.xpath('//*[text()="IOLMaster500QA"]'));
    this.IOLMaster700DEV=element(by.xpath('//*[text()="IOLMaster700DEV"]'));
    this.DEV_VLYNK=element(by.xpath('//*[text()="DEV-VLYNK"]'));
    this.DEV_DMLLENSX=element(by.xpath('//*[text()="DEV-DMLLENSX"]'));
    this.DEV_ARGOS=element(by.xpath('//*[text()="DEV-ARGOS"]'));
    this.DEV_VERIFEYEPLUS=element(by.xpath('//*[text()="DEV-VERIFEYEPLUS"]'));
    this.application_entity=element(by.xpath('//*[@formcontrolname="application_entity"]'));
    this.add_devices=element(by.xpath("//*[text()='ADD DEVICE']"));
    this.device_type_value=element(by.xpath('//*[text()="R-Zeiss700"]'));
    this.device_version_value=element(by.xpath('//*[text()="1.2"]'));
    this.device_serial_number_value_2=element(by.xpath('//*[text()="serial526unique"]'));
    this.dos_device_serial_number_value=element(by.xpath('//*[text()="serial1255dos"]'));
    this.dos_device_serial_number_value2=element(by.xpath('//*[text()="serial1255dos2"]'));
    this.dos_device_serial_number_value3=element(by.xpath('//*[text()="serial1255dos3"]'));
    this.dos_device_serial_number_value4=element(by.xpath('//*[text()="serial1255dos4"]'));
    this.dos_device_serial_number_value5=element(by.xpath('//*[text()="serial1255dos5"]'));
    this.dos_device_serial_number_value6=element(by.xpath('//*[text()="serial1255dos6"]'));
    this.manage_device_serial_number_value=element(by.xpath('//*[text()="serial243manage1"]'));
    this.manage_device_serial_number_value2=element(by.xpath('//*[text()="serial243manage2"]'));
    this.manage_device_serial_number_value3=element(by.xpath('//*[text()="serial243manage3"]'));
    this.device_Manufacturer_value=element(by.xpath('//*[text()="testManufacturer"]'));
    this.localAE_value=element(by.xpath('//*[text()="testlocalAE"]'));
    this.device_serial_number_value=element(by.xpath("//span[text()='createuniquegserial']"));
    this.application_entity_value=element(by.xpath('//*[text()="12345"]'));
    this.displayname_textbox=element(by.xpath("//label[text()=' Device Display Name ']/following::input"));
    this.edit_displayname_textbox=element(by.xpath("//label[text()='Device Display Name']/following::input"));
    this.duplicate_displayname_error=element(by.xpath("//small[text()='Device Display Name already exists']"));
    this.edit_new_displayname_should_match_the_pattern=element(by.xpath("(//small[text()='Display Name should match the pattern'])[2]"));
    this.new_edit_displayname_textbox=element(by.xpath("(//label[text()='Device Display Name'])[2]/following::input"));
    this.displayname_should_match_the_pattern=element(by.xpath("//small[text()='Display Name should match the pattern']"));
    this.port_number_value=element(by.xpath('//*[text()="8085"]'));
    this.storageAE_value=element(by.xpath('//*[text()="storageAE"]'));
    this.storageport_value=element(by.xpath('//*[text()="2345"]'));
    this.worklistAE_value=element(by.xpath('//*[text()="worklistAE"]'));
    this.worklist_value=element(by.xpath('//*[text()="8081"]'));
    this.Storage_port_error=element(by.xpath("//label[text()='Please enter value for  Storage Port ']"));
    this.edit_Storage_port_error=element(by.xpath("(//label[text()='Please enter value for  Storage Port '])[2]"));
    this.Storage_aetitle_error=element(by.xpath("//label[text()='Please enter value for  Storage AE Title ']"));
    this.edit_Storage_aetitle_error=element(by.xpath("(//label[text()='Please enter value for  Storage AE Title '])[2]"));
    this.worklist_port_error=element(by.xpath("//label[text()='Please enter value for  WorkList Port  ']"));
    this.edit_worklist_port_error=element(by.xpath("(//label[text()='Please enter value for  WorkList Port  '])[2]"));
    this.worklist_aetitle_error=element(by.xpath("//label[text()='Please enter value for  WorkList AE Title  ']"));
    this.edit_worklist_aetitle_error=element(by.xpath("(//label[text()='Please enter value for  WorkList AE Title  '])[2]"));
    this.io_bridge_path=element(by.xpath('//*[@placeholder="IO Bridge Path"]'));
    this.dicom_store_path=element(by.xpath('//*[@placeholder="DICOM Store Path"]'));
    this.io_bridge_path_value=element(by.xpath("(//div[@class='td-ellipsis']//span)[3]"));
    this.dicom_store_path_value=element(by.xpath("//a[@title='Device Details']"));
    this.IOBbidirectional_path_value=element(by.xpath("(//div[@class='td-ellipsis']//a)[2]"));
    this.proxy_IP_address_value=element(by.xpath('//*[text()="123.5.6.7"]'));
    this.proxyport_value=element(by.xpath('//*[text()="8907"]'));
    this.gateway=element(by.id('gatewayType'));
    this.device_group=element(by.xpath('//*[@formcontrolname ="deviceGroup"]'));
    this.device_type=element(by.id('deviceType'));
    this.Save_Configuration_Site_Network=element(by.xpath('//*[text()="Save Configure Site Network"]'));
//        this.practice=element(by.linkText('Practices'));
//        this.practice=element(by.xpath('/html/body/app-root/app-practices/app-site-network/app-view-site-network/div/div[1]/div/div[2]/a[1]'));
    this.practice=element(by.xpath('//*[@id="breadcrumbs1" and text()="Practices"]'));
    this.practiceInfo=element(by.linkText("Practice Info"));
    this.gateway_label=element(by.xpath('//label[text()=" Gateway Type "]'));
    this.gateway_ip_address_label=element(by.xpath('//label[text()=" IP Address "]'));
    this.device_type_label=element(by.xpath('//label[text()=" Device Type "]'));
    this.device_group_label=element(by.xpath('//label[text()=" Device Group "]'));
    this.device_serial_number_label=element(by.xpath('//label[text()=" Device Serial Number "]'));
    this.device_version_label=element(by.xpath('//label[text()=" Software Version "]'));
    this.io_bridge_path_label=element(by.xpath('//label[text()=" IO Bridge Path"]'));
    this.dicom_store_path_label=element(by.xpath('//label[text()=" DICOM Store Path "]'));
    this.Facility_tab=element(by.xpath("//*[text()='FACILITIES']"));
    this.listDevicesPractice_tab=element(by.xpath("//*[text()='DEVICES']"));
    this.SiteNetwork=element(by.xpath("//*[text()='Site Network']"));
    this.IOB_Bidirectional_path=element(by.xpath('//label[text()=" IOB Bidirectional Path "]'));
    this.Proxy_ip_Adress=element(by.xpath('//label[text()="Proxy IP Address "]'));
    this.Proxy_Port=element(by.xpath("//input[@formcontrolname='proxyPort']"));
    //this.Proxy_Port=element(by.xpath('//*[text()="Proxy Port"]'));
    this.IP_Address_should_match_the_IPv4_or_IPv6=element(by.xpath("//*[text()='IP Address should match the pattern']"));
    this.ip_Address_is_required=element(by.xpath("//*[text() ='IP Address cannot be blank']"));
    this.gateway=element(by.xpath("//*[@id ='gatewayType']"));
    this.somewhere=element(by.xpath("//*[text() ='Gateway Configuration']"));
    this.gateway_cannot_be_blank=element(by.xpath("//*[text() ='Gateway Type cannot be blank']"));
    this.device_group_cannot_be_blank=element(by.xpath("//*[text() ='Device Group cannot be blank']"));
    this.device_type_cannot_be_blank=element(by.xpath("//*[text() ='Device Type cannot be blank']"));
    this.Device_Serial_Number_should_be_an_alphanumeric_of_Charectors=element(by.xpath("//*[text()='Device Serial Number should be an alphanumeric of 6-18 Charectors']"));
    this.only_alpha_numeric_are_allowed=element(by.xpath("//*[text()='Only alphanumeric are allowed']"));
    this.Device_Serial_Number_is_required=element(by.xpath("//small[text()='Device Serial Number cannot be blank']"));
    this.Add_Device_Serial_Number_is_required=element(by.xpath("(//small[text()='Device Serial Number cannot be blank'])[2]"));
    this.device_version_should_match_the_pattern=element(by.xpath("//small[text()='Software Version should match the pattern']"));
    this.Device_Version_is_required=element(by.xpath("//*[text()='Software Version cannot be blank']"));
    this.storageAE_title=element(by.xpath("//label[text()='Storage AE Title ']"));
    this.storage_port=element(by.xpath("//*[text()='Storage Port ']"));
    this.worklistAE_title=element(by.xpath("//label[text()='WorkList AE Title ']"));
    this.worklist_port=element(by.xpath("//*[text()='WorkList Port ']"));
    this.localAE_title=element(by.xpath("//*[text()='Local AE Title ']"));
   // this.device_manufacturer=element(by.xpath("//*[text()=' Device Manufacturer']"));
    this.device_checkbox=element(by.xpath("//*[text()=' DICOM Compatible '] "));
    this.device_manufacturer=element(by.xpath("//label[text()=' Device Manufacturer ']"));
    this.Device_Manufacturer_textbox=element(by.xpath("//*[@placeholder='Device Manufacturer']"));
    this.storageAE_textbox=element(by.xpath("//*[@placeholder='Storage AE Title']"));
    this.storageAE_title_should_match_the_pattern=element(by.xpath("//*[text()='Storage AE Title should match the pattern']"));
    this.storageport_textbox=element(by.xpath("//*[@placeholder='Storage Port Number']"));
    this.storage_port_should_match_the_pattern=element(by.xpath("//*[text()=' Storage Port should match the pattern']"));
    this.worklistAE_textbox=element(by.xpath("//*[@placeholder='WorkList AE Title']"));
    this.worklistAE_title_should_match_the_pattern=element(by.xpath("//*[text()='WorkList AE Title should match the pattern']"));
    this.worklist_textbox=element(by.xpath("//*[@placeholder='WorkList Port']"));
    this.worklist_port_should_match_the_pattern=element(by.xpath("//*[text()=' Port number should match the pattern']"));
    this.Proxyiperrors_textbox=element(by.xpath("//*[@placeholder='Proxy IP Address']"));
    this.ProxyPort_textbox=element(by.xpath("//input[@placeholder='Proxy Port']"));
    this.Proxy_Port_should_match_the_pattern=element(by.xpath("//*[text()=' Proxy Port should match the pattern']"));
    this.Device_Type_SerialNum_Port_Should_be_Unique=element(by.xpath('//*[text()="DeviceType, Serial Number should be unique"]'));
    this.IOBbidirectional_path_textbox=element(by.xpath("//*[@placeholder='Bidirectional Path']"));
    this.facility=element(by.xpath("//*[@id='searchFacilityKey']"));
    this.only_alphabets_are_allowed_error=element(by.xpath("//*[text()='only alphabets are allowed']"));
 

//View_site_network_elements

    this.viewSiteNetwork = element(by.xpath('//li[@class="nav-item"]//a'));
    this.listOfDevices = element(by.xpath('//*[text()="List of Devices"]'));
    this.notConfiguredPracticesErrorMessage = element(by.linkText("Access Denied !You don't have permission to access Configure Site Network"));
    this.navigateBackToPracticePage = element(by.xpath('//*[@href="#/practices"]'));
    this.deviceConfTitlesInSiteNetwork = element(by.xpath("//*[contains(text(),'Device Configuration')]"));
    this.gateWayConfTitlesInSiteNetwork = element(by.xpath("//*[contains(text(),'Gateway Configuration')]"));
    this.dhsConfTitlesInSiteNetwork = element(by.xpath("//*[contains(text(),'DHS Configuration')]"));
    this.noDeviceRegisteredMessage = element(by.linkText("No Devices Registered for this practice"));
    this.viewMoreToolTip = element(by.xpath('//*[@id="list_devices"]/div/div/div/div/div/div/div[1]/strong/span'));
   this.searchBoxOfDevices = element(by.id('searchPracticeKey'));
    this.hsdpIDContent = element(by.xpath('//*[@class="table"]/tbody/tr[2]/td'));
//    this.connectivityContent = element(by.xpath(' //*[@class="table"]/tbody/tr[3]/td'));
    this.connectivityContent = element(by.xpath('/html/body/app-root/app-practices/app-site-network/app-view-site-network/div/div[2]/div[2]/app-list-devices/app-device-info/div[2]/table/tbody[1]/tr[1]/td[5]'));
    this.configure_site_network=element(by.id('gatewayType'));
    this.Are_you_sure_do_you_want_to_Restart_gateway_POPUP=element(by.xpath('//*[text()="Are you sure do you want to Restart Gateway/s ?"]'));
    this.Are_you_sure_do_you_want_to_deploy_gateway_POPUP=element(by.xpath('//*[text()="Are you sure do you want to deploy gateway/s ?"]'));
    this.login=element(by.id('username'));
    this.logmessage=element(by.xpath('//form/div[1]/div[1]/my-date-picker/div/div/input'));
    // this.practice=element(by.xpath('//*[@id="breadcrumbs1" and text()="Practices"]'));
    this.Edit_site_network=element(by.buttonText('ADD DEVICES'));
    this.edit_site_network=element(by.buttonText('EDIT SITENETWORK'));
    this.listdevice=element(by.xpath('//*[@id = "PracticeDetailsPracticeInfoTab" and contains(text(),"DEVICES")]'));
    this.Create_Practice=element(by.id('practiceListScreenTitle'));
    // this.Access_Denied=element(by.xpath('//strong[@_ngcontent-c9 and @style="text-align: center;" and text()="Access Denied !"]'));
    this.Back=element(by.linkText('Back'));
    this.edge_id2=element(by.xpath('//span[text()="1111-22ab-ft2"]'));

    //List devices elements

    this.list_view=element(by.id('language'));
    this.listdevices_serial_number=element(by.xpath("//*[contains(text(),'cerner56')]"));
    this.listdevices_device_type=element(by.xpath("//*[contains(text(),'Cerner')]"));
    this.list_devices_hsdp_id=element(by.xpath("//*[contains(text(),'8f536765-4174-4458-9d0c-d494c64069a1')]"));
    this.Aran_Eye_Care_device_type=element(by.xpath("//*[contains(text(),'R-Zeiss700')]"));
    this.Aran_Eye_Care_serial_number=element(by.xpath("//*[contains(text(),'Zeiss89098')]"));
    this.Aran_Eye_Care_identity_type=element(by.xpath("//*[contains(text(),'device')]"));
    this.chrome_Aran_Eye_Care_hsdp_id=element(by.xpath("//*[contains(text(),'a0677670-3819-41a9-9449-648f0a828711')]"));
    this.firefox_Aran_Eye_Care_hsdp_id=element(by.xpath("//*[contains(text(),'b544619e-6052-46df-9909-0e80f0e69122')]"));

//edit_site_network_Elements

this.edit_site_network=element(by.buttonText('EDIT SITENETWORK'));
this.add_device =element(by.buttonText('ADD DEVICE'));
this.edgeId_edit=element.all(by.xpath('//button[contains(text(),"Edit")]')).first();
this.save_edgeid=element(by.xpath("(//button[@class='ng-star-inserted'])[2]"));
this.gateway_type_edit=element.all(by.xpath('//button[contains(text(),"Edit")]')).get(1);
this.gateway_type_remove=element.all(by.xpath('//button[contains(text(),"Remove")]')).get(1);
this.device_configuration_1stDevice_edit=element(by.xpath("(//button[text()='Edit '])[2]"));
this.device_configuration_3rdDevice_edit=element(by.xpath("(//button[@data-target='#myModal'])[3]"));
this.device_configuration_Device_edit_1=element(by.xpath("(//button[@data-toggle='modal'])[2]"));
this.device_configuration_edit=element(by.xpath("(//td[@class='ng-star-inserted']//button)[3]"));
//this.device_configuration_edit=element(by.xpath('/html/body/app-root/app-practices/app-site-network/app-view-site-network/div/div[2]/div[2]/app-site-network-info/div[2]/form[2]/table/tbody/tr/td[13]/button[1]'));
//this.device_configuration_remove=element(by.xpath('//button[contains(text(),"Remove")]'));
this.save_site_network=element(by.xpath("//button[text()='SAVE SITENETWORK']"));
this.cancel_site_network=element(by.xpath('//button[@class="cancelbtn btn btn-primary ml-3 ng-star-inserted" and contains(text(),"CANCEL")]'));
this.cancel_sitenetwork=element(by.xpath('//button[contains(@class,"cancelbtn btn")]'));
this.save=element(by.xpath('//button[contains(text(),"Save")]'));
this.cancel=element(by.xpath('//button[contains(text(),"Cancel")]'));

this.ip_address_save=element(by.xpath('//button[contains(@class,"btn-sm ml-3")]'));
this.device_configuration_save=element(by.id('saveBtn'));
this.ip_address_cancel=element(by.xpath('//button[text()="Cancel"]'));
this.edit_Ip_Address_should_match_the_pattern=element(by.xpath('//*[text()="Ip Address should match the pattern"]'))
this.device_configuration_cancel=element.all(by.xpath('//button[contains(text(),"Cancel")]')).first();
//this.enabled_ip_address=element(by.xpath('/html/body/app-root/app-practices/app-site-network/app-view-site-network/div/div[2]/div[2]/app-site-network-info/form[1]/table/tbody/tr[1]/td[2]/span'));
this.edit_ip_address=element(by.xpath('//*[@formcontrolname="EditIp_address"]'));
this.edit_ip_address=element(by.xpath('//*[@formcontrolname="EditIp_address"]'));
this.edit_edgeid=element(by.xpath('//*[@formcontrolname="edgeId"]'));
// this.unedit_port=element(by.xpath('/html/body/app-root/app-practices/app-site-network/app-view-site-network/div/div[2]/div[2]/app-site-network-info/form[2]/table/tbody/tr[2]/td[2]/span'));
// this.unedit_serial_number=element(by.xpath('/html/body/app-root/app-practices/app-site-network/app-view-site-network/div/div[2]/div[2]/app-site-network-info/form[2]/table/tbody/tr[2]/td[3]/span'));
// this.unedit_version=element(by.xpath('/html/body/app-root/app-practices/app-site-network/app-view-site-network/div/div[2]/div[2]/app-site-network-info/form[2]/table/tbody/tr[2]/td[4]/span'));
this.edit_port=element(by.xpath('//*[@formcontrolname="EditDevice_port"]'));
this.edit_serial_number=element(by.xpath('//*[@id="myModal"]/div/div/div[2]/form/div[1]/div[1]/input'));
this.edit_storageae_title_textbox=element(by.xpath("//input[@ng-reflect-name='storageAETitle']"));
this.edit_storagport_textbox=element(by.xpath("//input[@placeholder='Storage Port']"));
this.edit_worklist_aetitle_textbox=element(by.xpath("//input[@placeholder='WorkList AE Title']"));
this.edit_worklist_aeport_textbox=element(by.xpath("//input[@placeholder='WorkList Port']"));
this.edit_version=element(by.xpath('//*[@id="myModal"]/div/div/div[2]/form/div[1]/div[2]/input'));
this.update_device_details=element(by.xpath('//button[text()="UPDATE DEVICE DETAILS"]'));
this.add=element(by.xpath('//button[@class="page-secondary-action-btn"]'));
this.new=element(by.buttonText('ADD DEVICES'));
this.addGateway=element(by.xpath('//button[text()="ADD GATEWAY "]'));
this.addGateway2=element(by.buttonText('ADD GATEWAY'));
this.new_cancel=element(by.xpath('//button[@class="btn-sm ml-3"]'));
this.data_saved=element(by.xpath('//*[contains(text(),"Data saved")]'));
this.new_remove=element(by.xpath('//tr[1]/td[13]/button[2]'));
this.new_device_group=element(by.xpath('//*[@formcontrolname="deviceGroup"]'));
this.new_port=element(by.xpath('//*[@formcontrolname="port"]'));
this.new_device_serial_number=element(by.xpath('//*[@id="addDeviceModal"]/div/div/form/div[1]/div[1]/div[3]/input'));
this.new_version=element(by.xpath('//*[@id="addDeviceModal"]/div/div/form/div[1]/div[1]/div[4]/input'));
this.Device_manufacturer=element(by.xpath('(//*[@ng-reflect-name="deviceManufacturer"])[2]'));

this.Device_manufacturer_CreateSiteNetwork=element(by.xpath("//label[text()=' Device Manufacturer ']/following::input"));
//this.add_device_details=element(by.xpath('//div/div/form/div[2]/button[2]'));
this.new_device_type=element(by.id('deviceType'));
this.new_cancel_symbol=element(by.xpath("(//button[text()='CLOSE'])[3]"));
this.add_device_details_edit=element(by.buttonText('ADD DEVICE DETAILS'));
this.add_device_details=element(by.buttonText('ADD DEVICE DETAILS'));
this.close_device_details=element(by.xpath('(//button[@class="btn btn-secondary"])[3]'));
//this.cancel_symbol=element(by.xpath('//*[@id="myModal"]/div/div/div[1]/button'));
this.new_portErrorMessage=element(by.id('PortErrorMessage'));
this.new_serialErrorMessage=element(by.id('DeviceSerialNumberPattern'));
this.new_versionErrorMessage=element(by.id('DevicePatternRequiredErrorMessage'));
this.new_ipaddress_value=element(by.xpath('//*[text()="125.7.89.4"]'));
this.new_edgeid_value=element(by.xpath('//*[text()="newedge1234"]'));
this.edgeid_526value=element(by.xpath('//*[text()="edge562"]'));
this.edgeid_4712value=element(by.xpath('//*[text()="edge4712"]'));
this.edgeid_1459value=element(by.xpath('//*[text()="edge1459"]'));
this.new_serial_number_value=element(by.xpath('//*[text()="iolmaster57"]'));
this.emr_serial_number_value=element(by.xpath("//span[text()='EMR123456']"));
this.new_device_group_value=element(by.xpath('//*[contains(text(),"EdgeDeviceType")]'));
this.new_port_value=element(by.xpath('//*[contains(text(),"8001")]'));
this.new_device_serial_number_value=element(by.xpath('//*[contains(text(),"Edge443")]'));
this.new_version_value=element(by.xpath("//span[text()='4.5']"));
this.edit_serial_number_value=element(by.xpath('//*[text()="epic12345"]'));
this.edit_oraserial_number_value=element(by.xpath('//*[text()="oradevice123"]'));
this.edit_ipaddress_value=element(by.xpath('//*[text()="127.8.4.3"]'));
this.edit_version_value=element(by.xpath('//*[text()="1.4"]'));
this.edit_io_path_value=element(by.xpath('//*[text()=" iopath"]'));
this.edit_dicom_path_value=element(by.xpath('//*[text()="dicompath"]'));
this.IOB_Bidirectional_Path_value=element(by.xpath('//*[text()="bidirectional"]'));
this.Proxy_IP_value=element(by.xpath('//*[text()="181.9.9.0"]'));
this.Proxy_IP_error=element(by.xpath("//small[text()='IP Address should match the pattern']"));
this.Proxy_Port_value=element(by.xpath('//*[text()="9078"]'));
this.Proxy_Port_error=element(by.xpath("//small[text()='Port should match the pattern']"));
this.success=element(by.xpath('//*[text()="Success!"]'));
this.new_device=element(by.xpath('//span[contains(text(),"8001")]'));
this.edit_io_path=element(by.xpath('//*[@formcontrolname="pathToIoBridge"]'));
this.edit_dicom_path=element(by.xpath('//*[@formcontrolname="pathToDicomStore"]'));
this.IOB_Bidirectional_Path=element(by.xpath('//*[@formcontrolname="pathToIOBBidirectionalPath"]'));
this.Proxy_IP=element(by.xpath('//*[@formcontrolname="proxyIPAddress"]'));
this.Proxy_Port=element(by.xpath('//*[@formcontrolname="proxyPort"]'));
this.device_deatials_window=element(by.xpath('//*[@class="modal-content"]'));
this.device_deatials_window2=element(by.xpath('//*[@class="modal-content"]'));
this.close=element(by.xpath('//div[@class="modal-content"]/div[3]/button[1]'));
this.gatewayclose=element(by.xpath('(//div[@class="modal-footer"]//button)[3]'));
this.dhs_edit=element.all(by.xpath('//*[@class="ng-star-inserted" and text()="Edit "]')).last();
this.new_close=element(by.xpath('//*[@id="addDeviceModal"]/div/div/form/div[2]/button[1]'));
this.dhs_save=element(by.xpath('//*[@class="ng-star-inserted" and text()="save "]'));

this.facility_device_configuration_edit=element(by.xpath('/html/body/app-root/app-practices/app-practice-details/div/div[2]/div/div/app-facilities/app-view-sitenetwork-facility/div[2]/app-site-network-info/div[2]/form[2]/table/tbody/tr/td[13]/button[1]'));
this.facility_new_remove=element(by.xpath('/html/body/app-root/app-practices/app-practice-details/div/div[2]/div/div/app-facilities/app-view-sitenetwork-facility/div[2]/app-site-network-info/div[2]/form[2]/table/tbody/tr/td[13]/button[2]'));
this.facility_dhs_edit=element(by.xpath("(//button[@class='ng-star-inserted'])[2]"));
this.facility_dhs_save=element(by.xpath("(//button[@class='ng-star-inserted'])[3]"));
this.facility_dhssave=element(by.xpath('(//*[text()="save "])[2]'));
this.facility_save_site_network=element(by.xpath('/html/body/app-root/app-practices/app-practice-details/div/div[2]/div/div/app-facilities/app-view-sitenetwork-facility/div[2]/app-site-network-info/div[2]/div[3]/button[2]'));
this.facility_cancel_symbol=element(by.xpath('//*[@id="addDeviceModal"]/div/div/div/button'));
this.listDevices_facility=element(by.linkText("ListDeviceFacility"));
this.Showing_101_105_of_105=element(by.xpath('//*[@className="pr-2" and text()="Showing 101 - 105 of 105"]'));
this.Showing_1_100_of_105=element(by.xpath("//*[@class='pr-2' and text()='Showing 1 - 100 of 105']"));
this.Showing_1_100_of_310=element(by.xpath("//*[@class='pr-2' and text()='Showing 1 - 100 of 310']"));
this.Showing_201_300_of_310=element(by.xpath("//*[@class='pr-2' and text()='Showing 201 - 300 of 310']"));
//this.listdevices_device_type2=element(by.linkText("Cerner"));
this.list_devices_hsdp_id2=element(by.xpath("//div[text()='d06182da-287e-4db3-bf6d-8c0ebe58df73']"));
// log_messages_Elements

    this.datePicker = element(by.xpath('//*[@class="ui-button-icon-left ui-clickable pi pi-calendar"]'));
    this.getLogMessage = element(by.buttonText('Get Log Data'));
    this.dateField = element(by.xpath('//*[@type="text"]'));
    this.logMessageText = element(by.linkText('Test_Log_Message'));
    this.get_Logdata=element(by.xpath('//*[@class="btn btn-primary" and text()="Get LogData"]'));  
    this.startdatepicker=element.all(by.xpath('//*[@aria-label="Open Calendar"]')).first();
    this.enddatepicker=element.all(by.xpath('//*[@aria-label="Open Calendar"]')).last();
    this.No_Log_Data_Found=element(by.xpath('//*[text()="No Log Data Found"]'));
    this.No_Device_Found=element(by.xpath('//*[text()="No Device Found"]'));
    this.log_message1=element(by.xpath('//*[text()="log_message1"]'));
    this.log_message2=element(by.xpath('//*[text()="log_message2"]'));
    this.start_date_selection=element(by.xpath('/html/body/app-root/app-practices/app-site-network/app-view-site-network/div/div[2]/div[2]/app-list-devices/app-log-message/form/div[1]/div[1]/my-date-picker/div/div/input'));
    this.end_date_selection=element(by.xpath('/html/body/app-root/app-practices/app-site-network/app-view-site-network/div/div[2]/div[2]/app-list-devices/app-log-message/form/div[1]/div[2]/my-date-picker/div/div/input'));


  //  deviceDetails_Elements

        this.EMR=element(by.xpath('//*[contains(text(),"EMR")]//span'));
        this.RVerion_device=element(by.xpath('//*[contains(text(),"DemoZeiss700 ")]//span'));
        this.RZeiss500_device=element(by.xpath('//*[contains(text(),"R-Zeiss500")]//span'));
        // this.device_details_title=element(by.xpath('//*[contains(text(),"device_details")]'));
        this.backtab=element(by.linkText('view_site_network'));
        this.Greys_hospital=element(by.linkText('Greys hospital'));
        this.Greys_hospital_practice=element(by.xpath('//*[contains(text(),"b24045fe-e090-4449-8858-15ed6536c617")]'));
        this.LogMessage=element(by.linkText('Log Message'));
        this.device_details_title=element(by.xpath('//*[contains(text(),"Device Details")]'))      
        this.device1=element(By.xpath("//a[@title='Device Details']"));
        this.alaska_device=element(by.xpath('/html/body/app-root/app-practices/app-practice-details/div[1]/div[2]/div[1]/div[1]/app-facilities/app-list-devices-facility[1]/div[2]/app-device-info/div[2]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/a[1]'));
        this.device2=element.all(by.xpath('/html/body/app-root/app-practices/app-site-network/app-view-site-network/div/div[2]/div[2]/app-list-devices/app-device-info/div/table/tbody[1]/tr/td[1]/div/a')).first();
         this.PracticeName=element(by.xpath('//*[contains(text(),"Practice Name")]'));
         this.FacilityName=element(by.xpath('//*[contains(text(),"Facility Name")]'));
        this.Practice_Id=element(by.xpath('//*[contains(text(),"Practice Id")]'));
        this.Identity_Type=element(by.xpath('//*[contains(text(),"Identity Type")]'));
        this.Display_Name=element(by.xpath('//*[contains(text(),"Display Name")]'));
        this.Device_Type=element(by.xpath('//*[contains(text(),"Device Type")]'));
        this.Serial_Number=element(by.xpath('//*[contains(text(),"Serial Number")]'));
        this.HSDP_ID=element(by.xpath('//*[contains(text(),"HSDP ID")]'));
        this.Connectivity_Status=element(by.xpath('//*[contains(text(),"Connectivity Status")]'));
        this.Connectivity_Status_header=element(by.xpath('//*[contains(text(),"Connectivity Status")]'));
        this.Last_Message_Received=element(by.xpath('//*[contains(text(),"Last Message Received")]'));


       // createpracticeAndfacility_Elements

            this.practice_Create_Practice_button=element(by.id('dhspracticelist-createpractice'));
            this.Address=element(by.xpath('//label[text()=" Address "]'));
            this.AddressInfo=element(by.xpath('//label[text()=" Address"]'));
            this.ora_practiceid=element(by.xpath("//div[@class='form-row col-lg-12']//label[1]"));
            this.ora_practiceid_textbox=element(by.xpath("//input[@class='dhs-textfield col-lg-2']"));
            this.edit_linkpractice=element(by.xpath("//input[@class='dhs-textfield col-lg-1']"));
            this.Practice_Name=element(by.xpath('//*[text()=" Practice Name "]'));
this.Practice_Id=element(by.xpath("//*[contains(text(),'Practice Id ')]"));
            this.Language=element(by.xpath('//label[@for="inputEmail4" and text()=" Language "]'));
            this.LanguageInfo=element(by.xpath('//*[text()=" Language "]'));
            this.Region=element(by.xpath('//label[text()=" Region "]'));
            this.Country=element(by.xpath('//label[text()=" Country "]'));
            this.ZipCode=element(by.xpath('//label[text()=" Zip Code"]'));
            this.First_Name=element(by.xpath('//label[text()=" First Name "]'));
            this.Last_Name=element(by.xpath('//label[text()=" Last Name "]'));
            this.Email=element(by.xpath('//label[text()=" Email "]'));
            this.Phone=element(by.xpath('//label[text()=" Phone"]'));
            this.Number=element(by.xpath('//label[text()=" Number "]'));
            this.Practice_Create_Button=element(by.id('createPracticeCreateButton'));
            this.create_Practice_Cancel_Button=element(by.id('createPracticeCancelButton'));
             this.practice_Information_section=element(by.xpath('//*[text()="Practice Information"]'));
            this.Test_Practice=element(by.xpath('//*[text()=" Test Practice "]'));
            this.Is_ORA_Sync_Enabled=element(by.xpath('//label[text()=" Is ORA Sync Enabled "]'));
            this.practise_random=element(by.xpath('/html/body/app-root/app-practices/app-practice-list/div/div/div[2]/div/table/tbody[1]/tr[4]/td[1]/div/a'));
            this.Practice_Name_textbox=element(by.xpath('//input[@id="practiceName" and @ng-reflect-name="practiceName"]'));
            this.PracticeName_textbox=element(by.xpath('//input[@id="practiceName" and @ng-reflect-name="practiceName"]'));
            this.Language_dropdown=element(by.xpath('//*[@formcontrolname="language"]'));
            this.Address_textbox=element(by.id('userAddress'));
            this.Region_dropdown=element(by.xpath('(//select[@ng-reflect-name="selectedRegion"])[2]'));;
            this.ZipCode_textbox=element(by.xpath('//*[@formcontrolname="zipCode"]'));
            this.ZipCodefac_textbox=element(by.xpath('//input[@formcontrolname="zipcode"]'));
            this.Type=element(by.xpath('//*[text()=" Type "]'));
            this.Country_dropdown=element(by.xpath('//*[@formcontrolname="selectedCountry"]'));
            this.Free=element(by.xpath('//*[@value="free"]'));
            this.Paid=element(by.xpath('//*[@value="paid"]'));
            this.User_Information=element(by.xpath('//*[text()="User Information"]'));
            this.First_Name_textbox=element(by.xpath('//*[@formcontrolname="userFirstName"]'));
            this.Last_Name_textbox=element(by.xpath('//*[@formcontrolname="userLastName"]'));
            this.Email_textbox=element(by.xpath('//*[@formcontrolname="userEmail"]'));
            this.Phone_dropdown=element(by.xpath('//*[@formcontrolname="userPhone"]'));
            this.Number_textbox=element(by.xpath('//*[@formcontrolname="userNumber"]'));
            this.state_textbox=element(by.xpath('//*[@formcontrolname="state"]'));
            this.astrix_Practice_Name=element(by.xpath('//label[text()=" Practice Name "]/span'));
            this.astrix_Language=element(by.xpath('//label[text()=" Language "]/span'));
            this.astrix_type=element(by.xpath('//label[text()=" Type "]/span'));
            this.astrix_Region=element(by.xpath('//label[text()=" Region "]/span'));
            this.astrix_country=element(by.xpath('//label[text()=" Country "]/span'));
            this.astrix_Zip_code=element(by.xpath('//label[text()=" Zip Code "]/span'));
            this.astrix_First_Name=element(by.xpath('//label[text()=" First Name "]/span'));
            this.astrix_Last_Name=element(by.xpath('//label[text()=" Last Name "]/span'));
            this.astrix_Email=element(by.xpath('//label[text()=" Email "]/span'));
            this.Create_Facility_title=element(by.xpath('//span[text()="Create Facility"]'));
            this.CreateFacility_title=element(by.linkText('Create Facility'));
            this.Create_Facility_checkbox=element(by.xpath("//input[@type='checkbox']"));
            this.Facility_Name=element(by.xpath('//*[text()=" Facility Name "]'));
            this.Alcon_Ship_to_Account=element(by.xpath('//*[text()=" Alcon Ship to Account # "]'));
            this.Address1=element(by.xpath('//*[text()=" Address1 "]'));
            this.Address2=element(by.xpath('//*[text()=" Address2 "]'));
            this.Country=element(by.xpath('//*[text()=" Country "]'));
            this.stateProvince=element(by.xpath('//*[text()=" State/Province "]'));
            this.state_province= element(by.xpath('//label[text()=" State/Province"]'));
            this.state=element(by.xpath('//*[text()=" State "]'));
            this.city=element(by.xpath('//*[text()=" City "]'));
            this.Zip_Code=element(by.xpath('//label[text()=" Zip Code"]'));
           
            this.Facility_Name_Textbox=element(by.xpath('//input[@id="facilityName"]'));
            this.Alcon_Ship_to_Account_Textbox=element(by.xpath('//input[@class="dhs-textfield ng-valid ng-touched ng-dirty"]'));
            this.Address1_textbox=element(by.xpath('//input[@id="practiceName" and @placeholder="Address1"]'));
            this.Address2_textbox=element(by.xpath('//input[@id="practiceName" and @placeholder="Address2"]'));;
            this.state_textbox=element(by.xpath('//select[@formcontrolname="state"]'));
            this.city_textbox=element(by.xpath('(//*[@id="practiceName"])[2]'));
            this.Zip_Code_textbox=element(by.xpath('//*[@formcontrolname="zipcode"]'));
            this.Cancel=element(by.xpath('//button[@class="btn btn-secondary mr-2"]'));
            this.create_button=element(by.xpath('//button[@id="createPracticeCreateButton"]'));
            this.astrix_Facility_Name=element(by.xpath('//label[text()=" Facility Name "]/span'));
            this.astrix_Address1=element(by.xpath('//label[text()=" Address1 "]/span'));
            this.astrix_Country=element(by.xpath('//label[text()=" Country "]/span'));
            this.astrix_City=element(by.xpath('//label[text()=" City "]/span'));
            this.only_alphabets_are_allowed=element(by.xpath("//*[text()='Only alphabets are allowed']"));
            this.Practice_Name_cannot_be_blank=element(by.xpath("//*[contains(@id,'GatewayTypeErrorMessage')]"));
            this.Zip_code_cannot_be_less_than_3digits=element(by.xpath("//*[text()='Zip code cannot be less than 3 digits']"));
            this.First_Name_is_required=element(by.xpath("//*[text()='First Name cannot be blank']"));
            this.Last_Name_is_required=element(by.xpath("//*[text()='Last Name cannot be blank']"));
            this.Invalid_Email=element(by.xpath("//*[text()='Invalid Email']"));
            this.Phone_number_is_invalid=element(by.xpath('//*[contains(text(),"Phone number is invalid")]'));
            //this.Zip_code_cannot_be_less_than_3digits=element(by.xpath('//*[text()="Zip code cannot be less than 3 digits"]'));
            this.practice_Info=element(by.xpath('//*[@id="PracticeDetailsPracticeInfoTab"]'));
            this.Create_Facility=element(by.xpath('//*[@class="dhs-button secondary-regular-button create-practice-list-button"]'));
            // this.Create_Facility=element(by.id('dhspracticelist-createpractice'));
            this.Facility_Name_is_required=element(by.xpath('//*[text()="Facility Name cannot be blank"]'));
            this.Address1_is_required=element(by.xpath('//*[text()="Address cannot be blank"]'));
            this.city_is_required=element(by.xpath('//*[text()="City cannot be blank"]'));
            this.search_facility=element(by.xpath("//*[@id='searchFacilityKey' and @placeholder='Search Facilities']"));
            //  PRACTICE INFO
            this.Create_facility_button=element(by.xpath("//*[@id='createPracticeCreateButton' and text()=' CREATE FACILITY ']"));
            this.ConnectivityStatus=element(by.xpath("//div[text()=' Connectivity Status ']"));
            this.deviceDisplayName=element(by.xpath("//div[text()=' Display Name ']"));
            this.LastMessageReceived=element(by.xpath("//div[text()=' Last Message Received ']"));
           
this.sorttable=element.all(by.xpath('//*[@title="Practice Details"]'));
this.logTime=element.all(by.xpath('//*[@title="Log creationTime"]'));

this.Transcationid=element.all(by.xpath('//*[text()="transactionId"]'));

this.logmessages=element.all(by.xpath('//*[@class="td-ellipsis" and text()="log_message1"]'));
this.Showing_1_10_of_15=element(by.xpath('//*[text()="Showing 1 - 10 of 15"]'));
// this.Page_Number_drop_down=element(by.xpath('//*[@class="col-sm-2 ng-untouched ng-pristine ng-valid"]'));
this.Page_Number_drop_down=element(by.xpath('//*[@class="ng-untouched ng-pristine ng-valid"]'));

this.page_number_drop_down_count=element.all(by.xpath('//option[@class="ng-star-inserted"]'));
this.Page_Number_drop_down_select=element(by.xpath('//*[@class="col-sm-2 ng-valid ng-touched ng-dirty"]'))
this.Showing_1_10_of_25=element(by.xpath('//*[text()="Showing 1 - 10 of 25"]'));
this.Showing_1_10_of_30=element(by.xpath('//*[text()="Showing 1 - 10 of 30"]'));


this.forward_arrow=element(by.xpath('//*[@src="assets/next.svg"]'));
this.Backward_arrow=element(by.xpath('//*[@src="assets/previous.svg"]'));
this.Time_header_arrow=element(by.xpath('//*[@src="/assets/images/sortB.svg"]'))
this.Transcation_header_arrow=element(by.xpath('//*[text()=" Transaction ID "] '))
this.Showing_31_40_of_55=element(by.xpath('//*[text()="Showing 31 - 40 of 55"]'));
this.Showing_21_30_of_30=element(by.xpath('//*[text()="Showing 21 - 30 of 30"]'));
this.Showing_1_10_of_40=element(by.xpath('//*[text()="Showing 1 - 10 of 40"]'));
this.Showing_31_40_of_40=element(by.xpath('//*[text()="Showing 31 - 40 of 40"]'));

this.Please_select_category
//new practice and facility elements

this.are_you_sure=element(by.xpath('//*[@class="alert-body body-content"]'));
this.alert_cancel=element(by.xpath("//div[@class='modal-content modal-alert']"));
this.No_thanks=element(by.xpath("//*[text()='NO THANKS']"));
this.yes_please=element(by.xpath("//*[text()='YES PLEASE']"));
this.practice_info_save_button=element(by.xpath('//*[text()=" SAVE "]'));
this.practice_info_cancel_button=element(by.xpath("//*[@id='createPracticeCancelButton']"));
this.Special_Characters_are_not_allowed =element(by.xpath("//*[text()='Special Characters are not allowed']"));
this.create_facility_128char_error=element(by.xpath('//small[text()="FacilityName cannot be more than 128 characters"]'));
this.practice_128char_error=element(by.xpath('//small[text()="Practise Name cannot be more than 128 characters"]'));
this.practice_updated_successfully=element(by.xpath('//*[text()="Practice Updated Successfully"]'));
this.Practice_Name_already_existing=element(by.xpath('//label[text()="practice is already existing in system."]'));
this.Alexandro_practice=element(by.linkText('Alexandro practice'));
this.Brielle_practice=element(by.linkText('Brielle practice'));
this.non_usa=element(by.linkText('testfacilitylink'));
this.edit_Address_textbox=element(by.xpath('//*[@formcontrolname="address"]'));
this.practice_info=element(by.xpath('//*[@id="PracticeDetailsPracticeInfoTab" and text()="PRACTICE INFO"]'));
this.Alexandrea_practice=element(by.linkText('Alexandrea practice'));
this.state_dropdown=element(by.xpath('//*[@formcontrolname="state"]'));
this.Facility_created_successfully=element(by.xpath('//*[text()="Facility Created in DHS Successfully"]'));
this.Edit_facility=element(by.xpath('//*[text()="Edit Facility"]'));
this.Address1_value=element(by.xpath('//*[text()="address"]'));
this.Address2_value=element(by.xpath('//*[text()="address45"]'));
this.city_value=element(by.xpath("//label[text()=' City ']"));
this.newpractice_radiobutton3=element(by.xpath("(//div[contains(@class,'custom-control custom-radio')]//label)[3]"));
this.newpractice_radiobutton2=element(by.xpath("(//div[contains(@class,'custom-control custom-radio')]//label)[2]"));
this.newpractice_radiobutton1=element(by.xpath("//div[contains(@class,'custom-control custom-radio')]//label"));
this.newfacility_radiobutton3=element(by.xpath("(//div[contains(@class,'custom-control custom-radio')])[3]"));
this.newfacility_radiobutton2=element(by.xpath("(//div[contains(@class,'custom-control custom-radio')])[2]"));
this.newfacility_radiobutton1=element(by.xpath("//div[contains(@class,'custom-control custom-radio')]"));
this.listpractice_popup=element(by.xpath("//h5[text()='List of practices ']"));
this.search_practice_textbox=element(by.xpath("//input[@placeholder='Search by name']"));
this.searched_practice=element(by.xpath("//p[text()='Alcon Product Sec']"));
this.save_practice_popup=element(by.xpath("//button[text()='Save changes']"));
this.close_practice_popup=element(by.xpath("//button[text()='Close']"));
this.facility_city_value=element(by.xpath("//label[text()=' City ']/following::input"));
this.Address1_inherit=element(by.xpath('//input[@id="practiceName" and @placeholder="Address1"]'));
this.ZipCode_inherit=element(by.xpath('//*[@formcontrolname="zipcode"]'));
this.city_inherit=element(by.xpath('//*[@formcontrolname="city"]'));
this.Facility_inheritName=element(by.xpath('//*[@formcontrolname="name"]'));
this.state_inherit=element(by.xpath('//*[@formcontrolname="state"]'));
this.Country_inherit=element(by.xpath('//*[@formcontrolname="country"]'));
this.Address_value=element(by.xpath('//*[text()="Addressvalue"]'));
this.Address2_value_2=element(by.xpath('//*[text()="address2"]'));
this.Facility_Updated_successfully=element(by.xpath('//*[text()="Facility Updated Successfully"]'));
this.practices=element.all(by.xpath('//table/tbody/tr/td[1]'));
this.practice_Names=element.all(by.xpath('//table/tbody/tr/td[1]'));
this.Name_header_arrow=element(by.xpath('//div[text()=" Name "]/span[1]/img'));
this.practiceId_header_arrow=element(by.xpath('//div[text()=" Practice Id "]'));
this.PAM_header_arrow=element(by.xpath('//div[text()=" PAM "]'));
this.Email_header_arrow=element(by.xpath('//div[text()=" Email "]'));
this.OraSyncEnabled_header_arrow=element(by.xpath('//div[text()=" ORA Sync Enabled "]'));
this.region_header_arrow=element(by.xpath('//div[text()=" Region "]'));
this.status_header_arrow=element(by.xpath('//div[text()=" Status "]'));
this.forward=element(by.xpath('//*[@class="ng-star-inserted" and @aria-label=" page"]'));
this.PAMs=element.all(by.xpath('//table/tbody/tr/td[3]'));
this.practiceIds=element.all(by.xpath('//table/tbody/tr/td[2]'));
this.Emails=element.all(by.xpath('//table/tbody/tr/td[4]'));
this.OraSyncEnabled=element.all(by.xpath('//table/tbody/tr/td[5]'));
this.regions=element.all(by.xpath('//table/tbody/tr/td[6]'));
this.status=element.all(by.xpath('//table/tbody/tr/td[7]'));
this.page1=element(by.xpath('//*[text()="1"]'));
this.search_practice_name=element(by.xpath('//*[text()="Apple"]'));
this.search_practiceId=element(by.xpath('//*[text()="839fa6a4-da9a-4e0c-8db0-45e6f9261ae5"]'));
this.search_email=element(by.xpath('//*[text()="akdfjhdfhkdhjf@mailinator.com"]'));
this.search_region=element(by.xpath('//*[text()="Japan"]'));
this.Europe=element(by.xpath('//*[text()="Europe"]'));
this.Afghanistan=element(by.xpath('//*[text()="Afghanistan"]'));
this.Untied_States=element(by.xpath('//*[text()="United States"]'));
this.Japan=element(by.xpath('//*[text()="Japan"]'));
this.DeviceType=element.all(by.xpath('//table/tbody/tr/td[1]'));
this.Facility_Name_table=element.all(by.xpath('//table/tbody/tr/td[2]'));
this.serialNumber=element.all(by.xpath('//table/tbody/tr/td[3]'));
this.hsdpId=element.all(by.xpath('//table/tbody/tr/td[5]'));

// new configure site network elements
this.XML_file_path=element(by.xpath('//*[text()="XML Files Path "]'));
this.Lenstar_IP=element(by.xpath("//*[@for='Application Entity' and text()='Lenstar IP ']"));
this.Lenstar_IP_textbox=element(by.xpath("//*[@formcontrolname='ipAddress' and @placeholder='Lenstar IP']"));
this.Bidirectional_IP_address=element(by.xpath('//*[text()="EMR System IP address"]'));
this.Port_Number=element(by.xpath('//*[text()="Gateway Port Number"]'));
this.Bidirectional_Port_Number=element(by.xpath('//*[text()="EMR System Port Number"]'));
this.Bidirectional_Port_Number_textbox=element(by.xpath('//*[@placeholder="EMR Port Number"]'));
this.Port_Number_textbox=element(by.xpath('//*[@placeholder="Port Number"]'));
this.Bidirectional_IP_address_textbox=element(by.xpath('//*[@formcontrolname="bidirectionalIPAddress"]'));
this.port_should_match_the_pattern=element(by.xpath('//*[text()="Port number should match the pattern"]'));
this.Device_Serial_Number_should_match_the_pattern=element(by.xpath("//small[text()='Device Serial Number should match the pattern']"));
this.Device_Serial_Number_Required_minimum_characters=element(by.xpath("//small[text()='Required minimum 8 characters']"));
this.edit_addnew_Device_Serial_Number_Required_minimum_characters=element(by.xpath("(//small[text()='Required minimum 8 characters'])[2]"));
this.Serial_number_shouldnt_be_more_than_30_characters=element(by.xpath("(//div[@class='inputfield-error-block ng-star-inserted']//small)[2]"));
this.Create_device_Serial_number_shouldnt_be_more_than_30_characters=element(by.xpath("(//small[@id='DeviceGroupErrorMessage'])[3]"));
this.device_version_shouldnt_be_more_than_30_characters=element(by.xpath('//*[text()="Software version shouldn\'t be more than 30 characters"]'));
//this.device_version_shouldnt_be_more_than_30_characters=element(by.xpath('//small[text()="Device Version should match the pattern"]'));
this.storageAE_title_should_match_the_pattern=element(by.xpath('//*[text()="Storage AE Title should match the pattern"]'));
this.StorageAETitle_should_be_more_than_2_characters=element(by.xpath('//*[text()="storage AE Title should be more than 2 Characters"]'))
this.StorageAETitle_shouldnt_be_more_than_30_characters=element(by.xpath('//*[text()="storage AE Title shouldn\'t be more than 16 characters"]'));
//this.storage_port_should_match_the_pattern=element(by.xpath('//*[text()="Storage Port should match the pattern"]'));
this.worklistAETitle_should_be_more_than_2_characters=element(by.xpath('//*[text()="worklist AE Title should be more than 2 Characters"]'));
this.worklistAETitle_shouldnt_be_more_than_30_characters=element(by.xpath('//*[text()="worklist AE Title shouldn\'t be more than 16 Characters"]'));
this.LocalAE_title_should_match_the_pattern=element(by.xpath('//*[text()="Local AE Title should match the pattern"]'));
this.LocalAETitle_should_be_more_than_2_characters=element(by.xpath('//*[text()="Local AE Title should be more than 2 Characters"]'));
this.LocalAETitle_shouldnt_be_more_than_30_characters=element(by.xpath('//*[text()="Local AE Title shouldn\'t be more than 16 Characters"]'));
this.Device_Manufacturer_is_required=element(by.xpath("//small[text()='Device Manufacturer cannot be blank']"));
this.Device_Manufacturer_should_match_the_pattern=element(by.xpath("//small[text()='only alphabets are allowed']"));
this.Device_Manufacturer_should_be_more_than_2_characters=element(by.xpath('//*[text()="Device Manufacturer should be more than 2 Characters "]'));
this.Device_Manufacturer_shouldnt_be_more_than_30_characters=element(by.xpath('//*[text()="Device Manufacturer shouldn\'t be more than 30 Characters "]'));
this.LocalAE_textbox=element(by.xpath('//*[@formcontrolname="localAETitle"]'));
this.IP_Address_should_match_the_pattern=element(by.xpath('//*[text()="IP Address should match the pattern "]'));
this.gateway_remove=element.all(by.id('dhs-sidebarmenu-close')).last();
this.device_remove=element(by.xpath("html[1]/body[1]/app-root[1]/app-practices[1]/app-practice-details[1]/div[1]/div[2]/div[1]/div[1]/app-facilities[1]/app-configure-sitenetwork-facility[1]/app-configure-site-network[1]/div[2]/div[1]/div[1]/div[1]/div[3]/div[2]/div[1]/table[1]/tbody[1]/tr[3]/td[6]/img[1]"));
this.gateway_first=element.all(by.id('dhs-sidebarmenu-close')).get(1);
this.SerialNum_Should_be_Unique=element(by.xpath("//small[text()='Serial Number already exists']"));
this.gateway_popup=element(by.xpath('//button[@class="dhs-button secondary-regular-button"]'));
this.gateway_popuptrue=element(by.xpath('//button[@class="dhs-button primary-regular-button"]'));
this.EMR_value=element(by.xpath('//td[text()="EMR"]'));
this.OpenEMRDev=element(by.xpath('//*[text()="OpenEMRDev"]'));
this.Cerner=element(by.xpath("//span[text()='Cerner']"));
this.addEMR= element(by.xpath('//span[text()="EMR"]'));
this.Lenstar900DEV=element(by.xpath("//*[text()='Lenstar900DEV']"));
this.Lenstar900DEV_text=element(by.xpath("//span[text()='Lenstar900DEV']"));
this.Atlas9000DEV=element(by.xpath("//td[text()='Atlas9000DEV']"));
this.Atlas9000DEV_text=element(by.xpath("//span[text()='Atlas9000DEV']"));
this.lenstar_device_version_value=element(by.xpath('//*[text()="123.564"]'));
this.lenstar_device_serial_number_value=element(by.xpath('//*[text()="serial8990"]'));
this.lenstar_device_serial_number_value2=element(by.xpath('//*[text()="serial89902"]'));
this.lenstar_device_version_value_text=element(by.xpath('//span[text()="123.564"]'));
this.lenstar_device_serial_number_value_text=element(by.xpath('//span[text()="serial8990"]'));
this.oradevice_device_serial_number_value=element(by.xpath('//*[text()="viewylnk89900"]'));
this.oradevice_device_serial_number_value_2=element(by.xpath('//*[text()="dmllennsx89900"]'));
this.new_oradevice_device_serial_number_value=element(by.xpath('//*[text()="dmllennsxtest1233"]'));
//new edit elements


this.edit_Bidirectional_IP_address=element(by.xpath('//*[text()="Bidirectional IP Address"]'));
this.edit_devicemanufacturer=element(by.xpath('//*[@id="addDeviceModal"]/div/div/form/div[1]/div[2]/div[1]/label'));
this.edit_storageAE_title=element(by.xpath("(//label[text()='Storage AETitle'])[2]"));
this.edit_storageAEtitle=element(by.xpath('(//*[text()="Storage AETitle"])[2]'));
this.update_storageAEtitle=element(by.xpath("//label[text()='Storage AETitle']"));
this.edit_storage_port=element(by.xpath("(//label[text()='Storage Port'])[2]"));
this.update_storage_port=element(by.xpath("//label[text()='Storage Port']"));
this.editworklistAE_title=element(by.xpath("(//label[text()='Worklist AETitle'])[2]"));
this.update_worklistAE_title=element(by.xpath("//label[text()='Worklist AETitle']"));
this.edit_worklist_port=element(by.xpath("(//label[text()='Worklist Port'])[2]"));
this.update_worklist_port=element(by.xpath("//label[text()='Worklist Port']"));
this.edit_localAE_title=element(by.xpath("(//label[text()='Local AETitle'])[2]"));
this.update_localAE_title=element(by.xpath("//label[text()='Local AETitle']"));
this.Device_Serial_number_shouldnt_be_more_than_30_characters=element(by.xpath('//*[text()="Device Serial Number shouldn\'t be more than 30 characters"]'));
this.edit_StorageAETitle_shouldnt_be_more_than_30_characters=element(by.xpath("//small[@id='DevicePatternRequiredErrorMessage']"));
this.DeviceType_Serial_Number_and_Port_Should_not_be_duplicate=element(by.xpath('//*[@id="addDeviceModal"]/div/div/h5'));
this.new_storageAE_textbox=element(by.xpath("(//input[@formcontrolname='storageAETitle'])[2]"));
this.new_storageport_textbox=element(by.xpath("(//input[@formcontrolname='storagePort'])[2]"));
this.new_worklistAE_textbox=element(by.xpath("(//input[@formcontrolname='worklistAETitle'])[2]"));
this.new_worklist_textbox=element(by.xpath("(//input[@formcontrolname='worklistPort'])[2]"));
this.new_LocalAE_textbox=element(by.xpath("(//input[@formcontrolname='localAETitle'])[2]"));
this.edit_storageAE_title_should_match_the_pattern=element(by.xpath("(//small[text()='Storage AE Title should match the pattern'])[2]"));
this.edit_StorageAETitle_should_be_more_than_2_characters=element(by.xpath("(//small[text()='storage AE Title should be more than 2 Characters'])[2]"));
//this.edit_StorageAETitle_shouldnt_be_more_than_30_characters=element(by.xpath('//form/div[1]/div[2]/div[2]/div/div/small'));
this.edit_storage_port_should_match_the_pattern=element(by.xpath("(//small[text()=' Storage Port should match the pattern'])[2]"));
this.edit_worklistAE_title_should_match_the_pattern=element(by.xpath("(//small[text()='WorkList AE Title should match the pattern'])[2]"));
this.edit_worklistAETitle_should_be_more_than_2_characters=element(by.xpath("(//small[text()='worklist AE Title should be more than 2 Characters'])[2]"));
this.edit_worklistAETitle_shouldnt_be_more_than_30_characters=element(by.xpath("//div[@id='addDeviceModal']/div[1]/div[1]/form[1]/div[1]/div[4]/div[3]/div[1]/div[1]/small[1]"));
this.edit_worklist_port_should_match_the_pattern=element(by.xpath("(//small[text()=' Port number should match the pattern'])[2]"));
this.edit1_worklistAETitle_shouldnt_be_more_than_30_characters=element(by.xpath("//div[@class='inputfield-error-block ng-star-inserted']//small"));
this.worklistAETitle_shouldnt_be_more_than_30_characters_edit=element(by.xpath("//div[@id='addDeviceModal']/div[1]/div[1]/form[1]/div[1]/div[5]/div[3]/div[1]/div[1]/small[1]"));
this.edit_LocalAETitle_should_match_the_pattern=element(by.xpath("(//small[text()='Local AE Title should match the pattern'])[2]"));
this.edit_LocalAETitle_should_be_more_than_2_characters=element(by.xpath("(//small[text()='Local AE Title should be more than 2 Characters'])[2]"));
this.edit_LocalAETitle_shouldnt_be_more_than_30_characters=element(by.xpath("//div[@id='addDeviceModal']/div[1]/div[1]/form[1]/div[1]/div[4]/div[5]/div[1]/div[1]/small[1]"));
this.edit1_LocalAETitle_shouldnt_be_more_than_30_characters=element(by.xpath("//div[@id='myModal']/div[1]/div[1]/div[2]/form[1]/div[2]/div[3]/div[5]/div[1]/div[1]/div[1]/small[1]"));
this.LocalAETitle_shouldnt_be_more_than_30_characters_edit=element(by.xpath("//div[@id='addDeviceModal']/div[1]/div[1]/form[1]/div[1]/div[5]/div[5]/div[1]/div[1]/small[1]"));
this.edit_Device_Serial_Number_should_match_the_pattern=element(by.xpath('//form/div[1]/div[1]/div[3]/div[1]/div[1]/small'));
this.edit_Serial_number_shouldnt_be_more_than_30_characters=element(by.xpath('//form/div[1]/div[1]/div[3]/div[1]/div[1]/small'));
this.edit_firstdevice_Serial_number_shouldnt_be_more_than_30_characters=element(by.xpath("//div[@class='inputfield-error-block ng-star-inserted']//small"));
this.edit_device_version_should_match_the_pattern=element(by.xpath('//form/div[1]/div[1]/div[4]/div[1]/div[1]/small'));
this.edit_device_version_shouldnt_be_more_than_30_characters=element(by.xpath('//form/div[1]/div[1]/div[4]/div[1]/div[1]/small'));
this.edit_ipaddress_value_1=element(by.xpath('//*[text()="123.0.0.1"]'));
this.log_message2=element(by.xpath('//*[text()="log_message2"]'));
this.IP_Address_should_match_pattern=element(by.xpath('//*[text()="IP Address should match pattern"]'));
this.Facilities=element(by.linkText('Facilities'));
this.usafacility=element(by.linkText('usafacility'));
this.region=element(by.xpath('//label[text()=" Region "]'));
this.Address_cannot_be_more_than_255_characters=element(by.xpath('//*[text()="Address cannot be more than 255 characters"]'));
this.edit_Address2_textbox=element(by.xpath('//*[@placeholder="Address"]'));
this.editfacility_address2_textbox=element(by.xpath('//input[@formcontrolname="address2"]'));
this.SAP_Sold_To_Account=element(by.xpath('//label[text()="SAP Sold-To Account "]'));
this.salesforceid=element(by.xpath('//*[text()="Salesforce ID "]'));
this.salesforceid_textbox=element(by.xpath('//*[@formcontrolname="salesforceId"]'));
this.Alcon_Ship_to_Account_textbox=element(by.xpath('//*[@formcontrolname="alconShipToAccountNumber"]'));
this.SAP_Sold_To_Account_Textbox=element(by.xpath('//*[@formcontrolname="sapSoldToAccount"]'));
this.edit_storageAE_value = element(by.xpath('//*[@formcontrolname="storageAETitle"]'));

this.edit_storagePort = element(by.xpath('//label[text()="Storage Port"]'));

this.edit_worklistAETitle = element(by.xpath('//*[@formcontrolname="worklistAETitle"]'));
this.edit_worklistPort = element(by.xpath('//*[@formcontrolname="worklistPort"]'));

this.Lewis=element(by.linkText('Lewis'));
this.return_facility=element(by.linkText('Facilities'));
this.Access_Denied_for_listdevices=element(by.xpath('//*[text()="You dont\' have permission to access Devices"]'));
this.Access_Denied_for_sitenetwork=element(by.xpath('//*[text()="You dont\' have permission to access View Site Network "]'));
this.Access_Denied_for_configuresitenetwork=element(by.xpath('//*[text()="Access Denied !"]'));


///////UINote/////////////////////////////
this.UINote_Tab_Note=element(by.xpath('//*[@title="Ui Notes"]'));
this.Devices_Tab_Note=element(by.xpath('//*[text()="DEVICES"]'));
this.Facilities_Tab_Note=element(by.xpath('//*[text()="FACILITIES"]'));
this.Practice_Info_Tab_Note=element(by.xpath('//*[text()="PRACTICE INFO"]'));
this.UI_Notes_text=element(by.xpath('//*[text()="UI Notes"]'));
this.All_Dropdown=element(by.xpath('//*[text()="All"]'));
this.Submit_note_button=element(by.xpath('//*[text()=" Submit "]'));
this.Please_select_category=element(by.xpath('//*[text()="please select category"]'));
this.Add_Notes_text=element(by.xpath('//*[@placeholder="Add Notes"]'));
this.Please_select_category_dropdown=element(by.xpath('//*[@id="notes-container"]/div[3]/ul/li[1]/div/select'));
this.All_Notes=element(by.xpath('//*[@id="notes-container"]/div[1]/div/div[2]/select'));
this.Devicelognotes=element(by.xpath('//*[text()="Devicelognotes"]'));
this.LoggedInUser=element(by.xpath('//*[text()=""]'));
this.SiteNetworkConfigurationnotes=element(by.xpath('//*[text()="SiteNetworkConfigurationnotes"]'));
this.DeviceConnectivitynotes=element(by.xpath('//*[text()="DeviceConnectivitynotes"]'));
this.Note_close_button=element(by.xpath('//*[@id="notes-close-link"]'));
this.practicelink_tab=element(by.xpath('//*[@href="#/practices" ]'));
this.NoNotes_Practice=element(by.xpath('//*[text()="NoNotesPractice"]'));
this.Name_header=element(by.xpath('//*[text()=" Name "]'));
this.UIMessageNote=element(by.xpath('//*[text()="UIMessageNote"]'));
this.Category_deviceconnectivity=element(by.xpath('(//*[text()="device connectivity"])[2]'));
this.Category_deviceLogs=element(by.xpath('(//*[text()="device logs"])[2]'));
this.Category_SiteNetworkConfiguration=element(by.xpath('(//*[text()="site network configuration"])[2]'));
// Epic////
this.searched_practice_epic=element(by.xpath('(//*[@class="container ng-star-inserted"])[1]'));
this.LinkPractice_create=element(by.xpath('//*[text()=" LINK PRACTICE "]'));
this.Facility_DHS_successfully=element(by.xpath('//*[text()="Facility Created in DHS Successfully"]'));
//Practice and facility Radio button//
this.DHSORA_Radio=element(by.xpath('//*[@for="customRadioInline2"]'));
this.LinktoExistingFacility_Radio=element(by.xpath('//*[@for="customRadioInline3"]'));
//UTCStamp////
this.Toggale=element(by.xpath('//*[@for="checkedValue"]'));
//Pentacam//
this.PentacamPractice=element(by.xpath('//*[text()="PentacamPractice"]'));
//TranscationID//
this.TransactionID=element(by.xpath('//*[text()="bdce4f5c-bf19-4916-9bbe-f915c11c9210"]'));
//NGENUITY
this.NGENUITYPRACTICE=element(by.xpath('//*[@title="NGENUITYPRACTICE"]'));
// //DeviceSerial
// this.DeviceSerial=element(by.xpath('//*[@placeholder="Device Serial Number"]'));
this.DHS_and_ORA_radiobutton1=element(by.xpath('//*[text()="DHS and ORA"]'));
//UiNote attachment
this.usafacility_link=element(by.xpath('//*[text()="usafacility"]'));
this.Create_facility=element(by.xpath('//*[text()=" CREATE FACILITY "]'));
this.Create_facility_page=element(by.xpath('//*[text()="Create Facility"]'));
this.Ngenuity_practice=element(by.xpath('//*[text()="NGENUITYPRACTICE"]'));
this.Configure_SiteNetwork=element(by.xpath('//*[text()="Configure SiteNetwork"]'));
this.LogMessage_page=element(by.xpath('//*[text()="Log Messages"]'));
this.Abbie_practice=element(by.xpath('//*[text()="Abbie practice"]'));
this.Site_network_Info=element(by.xpath('//*[text()="Site network Info"]'));
this.Edge_Info=element(by.xpath('//*[text()="EDGE INFO"]'));
this.Edge_Info_page=element(by.xpath('//*[text()="Edge Info"]'));
this.site_network_info_page=element(by.xpath('(//*[@id="breadcrumbs1"])[4]'));
///Note Icon
this.Note_Icon=element(by.xpath('//*[@title="Ui Notes"]'));
//title="Ui Notes"
this.Notes_close=element(by.xpath('(//*[@id="notes-close-link"])[2]'));
this.Note_window=element(by.xpath('//*[text()="Notes"]'));

this.Notes_button=element(by.xpath('//*[@id="notes-close-link"]'));
this.Attach_files=element(by.xpath('//*[text()=" Attach files "]'));
this.pleaseselect_category=element(by.xpath('//*[text()="please select category"]'));

this.DHS_and_ORA_radiobutton1=element(by.xpath('//*[text()="DHS and ORA"]'));
this.Link_to_existing_practice_in_ORAradiobutton2=element(by.xpath('//*[text()="Link to existing practice in ORA"]'));

this.DownloadPractice=element(by.xpath('//*[text()="DownloadPractice"]'));
this.Attachmnets_pdf=element(by.xpath('//*[text()="sample2.pdf"]'));
this.Attachmnets_word=element(by.xpath('//*[text()="file-sample_100kB.docx"]'));
this.Attachmnets_text=element(by.xpath('//*[text()="sample1.txt"]'));
this.Attachmnets_image=element(by.xpath('//*[text()="DTL_log.PNG"]'));
this.Attachmnets_excel=element(by.xpath('//*[text()="Data Bleanding File One.xlsx"]'));
this.word_text=element(by.xpath('//*[text()="word"]'));
this.text=element(by.xpath('//*[text()="text"]'));
this.pdf_text=element(by.xpath('//*[text()="pdf"]'));
this.image_text=element(by.xpath('//*[text()="dfd"]'));
this.execl_text=element(by.xpath('//*[text()="excel"]'));

this.practicenotes=element(by.xpath('//*[text()="practicenotes"]'));
this.facilitynotes=element(by.xpath('//*[text()="facilitynotes"]'));
this.sitenetworknotes=element(by.xpath('//*[text()="sitenetworknotes"]'));
this.deviceconnectivitynotes=element(by.xpath('//*[text()="DeviceConnectivitynotes"]'));
this.devicelogsnotes=element(by.xpath('//*[text()="Devicelognotes"]'));
this.edgeinfonotes=element(by.xpath('//*[text()="edgeinfonotes"]'));

this.Facility_checkbox=element(by.xpath("(//input[@type='checkbox'])[2]"));
 
this.NewIICpractice_link=element(by.linkText("NewIICpractice"));
this.LinkPractice_Next = element(by.xpath("//button[contains(text(),'Next')]"));
this.LinkPractice_FirstRow = element(by.xpath("//div[@class='row']/div[1]"));
this.FacilityAddress2 =  element(by.xpath("//*[@formcontrolname='address2']"));
this.Enter_Notes_text = element(by.xpath('//*[@placeholder="Enter Notes here"]'));
///////////
this.No = element(by.xpath("//button[text()='NO']"));
//suspend practice
this.show_suspend_practice_checkbox = element(by.xpath('//*[@id="exampleCheck2"]'));
this.suspend_button=element(by.xpath('//*[text()="Suspend"]'));
this.practices=element(by.xpath('//*[@id="breadcrumbs1"]'));
this.Practice_Name_textbox1=element(by.xpath('(//*[@id ="practiceName"])[1]'));
this.Suspend_Practice=element(by.xpath('//*[@placeholder="Search Practices"]'));
this.Practice_Suspended_Sucessfully_POPUP=element(by.xpath('//*[text()="Clinic Practice Suspended Successfully in both DHS and ORA !"]'));
this.Ok=element(by.xpath('//*[text()="Ok"]'));
this.restore_button=element(by.xpath('(//*[text()="Restore"])[1]'));
this.Practice_restored_Sucessfully=element(by.xpath('//*[text()="Clinic Practice Restored Successfully in both DHS and ORA !"]'));
this.existing_Suspend_Practice_Name=element(by.xpath('//*[text()="0dcea6c3c7a5495596f1bc4b0d0090b6"]'));
this.Newly_created_Suspend_Practice=element(by.xpath('//*[text()="suspend practice newly createdone"]'));

this.Practice_Type_dropdown=element(by.xpath('(//*[@ng-reflect-name="selectedRegion"])[1]'));
this.Practice_Created_in_DHS_and_ORA_Successfully=element(by.xpath('//*[text()="Practice Created in DHS and ORA Successfully"]'));
this.Ok_new_practice=element(by.xpath('//*[text()="ok"]'));
this.Newly_created_Suspend_Practice_restore = element(by.xpath('(//*[text()="Restore"])[1]'));
this.existing_Suspend_Practice_Name_value =element(by.xpath('//*[text()="4586a287-57b2-4ec9-93fc-d287009a451a"]'));
this.inactive_status =element(by.xpath('(//*[text()="Inactive"])[1]'));
this.active_status =element(by.xpath('(//*[text()="active"])[1]'));
this.No_Practices_Found =element(by.xpath('//*[text()="No Practices Found"]'));
this.particular_practice_field=element(by.xpath('/html/body/app-root/app-practices/app-practice-list/div/div/div[2]/div/table/tbody[1]/tr/td[1]'));
this.search_box = element(by.xpath('//*[@id="searchPracticeKey"]'));
this.save_edgeid_1 =element(by.xpath('//*[text()="save "]'));
this.Edit_Sitenetwork_1 =element(by.xpath('//*[text()="EDIT SITENETWORK"]'));
this.Cancel_1=element(by.xpath('//*[text()="CANCEL"]'));
 this.Cancel_12=element(by.xpath('(//*[text()="CANCEL"])[2]'));
 this.cancel_symbol=element(by.xpath('(//button[@class="close"])[3]'));
 this.deploy_popup=element(by.xpath('//button[text()="No"]'));
this.restart_popup=element(by.xpath('//button[text()="No"]'));
this.Device_checkbox=element(by.xpath("(//input[@type='checkbox'])[2]"));
this.device_checkbox_1=element(by.xpath("(//input[@type='checkbox'])[3]"));

this.New_edge_device_is_configured_click_REMOVE_and_DEPLOY_to_reflect_the_changes=element(by.xpath('(//*[text()="New edge device is configured, Please click REMOVE and DEPLOY to reflect the changes"]'));
this.DHSIICAppTestDemoone_link=element(by.linkText('DHSIICAppTestDemoone'));
this.SiteNetwork_1=element(by.xpath("(//*[text()='Site Network'])[1]"));
this.edit_site_network_1=element(by.buttonText('EDIT SITENETWORK'));
this.yes_button_1=element(by.buttonText('Yes'));
this.yes_button=element(by.xpath("//*[text()='YES']"));
this.Name_gateway=element(by.xpath('//*[text()=" Name "]'));
this.version_gateway=element(by.xpath('//*[text()=" Version "]'));
this.deployed_date_gateway=element(by.xpath('//*[text()=" Deployed Date "]'));
this.ports_gateway=element(by.xpath('//*[text()=" Ports "]'));
this.remove_edge=element(by.buttonText('Remove'));
this.status_edge=element(by.buttonText('Status'));
this.deploy_edge=element(by.buttonText('Deploy'));
this.deploy_status_success=element(by.xpath('//*[text()="Success"]'));
this.deploystatus_close=element(by.xpath('//*[text()="×"]'));
this.restart_edge=element(by.xpath('//*[text()="Restart"]'));
this.Ok_gateway=element(by.xpath('//*[text()="OK"]'));
this.deploy_status_completed=element(by.xpath('(//*[text()="Completed"])[1]'));
this.edgeId_1=element(by.xpath("//*[@ng-reflect-name='edgeId']"));
this.deploy_popup=element(by.xpath('//button[text()="No"]'));
this.restart_popup=element(by.xpath('//button[text()="No"]'));
this.device_checkbox1=element(by.xpath('(//input[@type="checkbox"])[2]'));
// this.device_checkbox_1=element(by.xpath('(//input[@type="checkbox"])[3]'));
this.DPClinic_link=element(by.linkText('DPClinic'));
this.device_serial_number_3=element(by.xpath("//*[@placeholder='Device Serial Number']"));
this.cross_symbol=element(by.xpath("(//button[@class='close'])[1]"));
this.device_Serial_number_cannot_be_blank=element(by.xpath("(//small[text()='Device Serial Number cannot be blank'])[1]"));
this.Gateway_deployment_initiated_successfully=element(by.xpath('//*[text()="Gateway deployment initiated successfully"]'));
this.Gateway_Details_found_with_date_and_time=element(by.xpath('//*[text()="Gateway Details"]'));

//identify test practice
 
this.show_test_practice_checkbox=element(by.xpath('//*[@id="exampleCheck1"]'));
this.Test_Practice_checkbox=element(by.xpath('//input[@name="customRadioInline1"]'));
//this.ok_button=element(by.xpath('//button[text()="ok"]'));
this.successfull_message=element(by.xpath('//p[text()="Practice Created in DHS and ORA Successfully"]'));
this.create_Practice=element(by.xpath("//button[text()=' CREATE PRACTICE ']"));
this.existing_Suspend_Practice_Name_1=element(by.xpath('//*[text()="ASCRS TradeShow"]'));
this.Facility_Created_in_DHS_and_ORA_Successfully=element(by.xpath('//*[text()="Facility Created in DHS and ORA Successfully"]'));
//this.ok_button=element(by.xpath('//button[text()="ok"]'));
this.search_facility=element(by.xpath("//*[@id='searchFacilityKey' and @placeholder='Search Facilities']"));
this.restart_popup=element(by.xpath('//button[text()="No"]'));
this.Address1_textbox=element(by.xpath('//*[@placeholder="Address1"]'));
this.city_textbox=element(by.xpath('//*[@placeholder="City"]'));


// 5732 remodification xpaths

 

this.updated_message=element(by.xpath('//p[text()="Practice updated successfully "]'));
this.city_box=element(by.xpath('(//*[@id="practiceName"])[5]'));
this.address_box=element(by.xpath('(//*[@id="practiceName"])[3]'));
//this.facility_message=element(by.xpath("//p[text()='Facility Created in DHS and ORA Successfully']"));
//this.ok_button=element(by.xpath('//button[text()="ok"]'));
this.successfull_message=element(by.xpath('//p[text()="Practice Created in DHS and ORA Successfully"]'));
this.No_Practices_Found_info=element(by.xpath('//*[text()="No Practices Found"]'));
this.status_in_active=element(by.xpath('//*[text()="active"]'));
this.status_in_inactive=element(by.xpath('//*[text()="Inactive"]'));

this.region_modif=element(by.xpath("//select[@ng-reflect-name='selectedRegion']"));
this.Region_dropdown1=element(by.xpath('//*[@formcontrolname="selectedRegion"]'));

//28707

this.Attachmnets_pdf1=element(by.xpath("(//div[@class='pb-1 ng-star-inserted']//a)[1]"));
this.Attachmnets_word1=element(by.xpath("(//div[@class='pb-1 ng-star-inserted']//a)[2]"));
this.Attachmnets_text1=element(by.xpath("(//div[@class='pb-1 ng-star-inserted']//a)[3]"));
this.Attachmnets_image1=element(by.xpath("(//div[@class='pb-1 ng-star-inserted']//a)[4]"));
this.Attachmnets_excel1=element(by.xpath("(//div[@class='pb-1 ng-star-inserted']//a)[5]"));

//32513
this.Deploy_gateway_No=element(by.xpath('//*[text()="No"]'));
this.Facility_link=element(by.xpath('(//*[@id="breadcrumbs1"])[3]'));

//32254
this.practice_info1=element(by.xpath('//*[@ng-reflect-klass="breadcrumb-item active  cursor"]'));
  this.ORA_Practice_Name=element(by.xpath('//*[@for ="ORAPracticeId"]'));
 
  //5732
this.City_Name_cannot_be_more_than_56_characters=element(by.xpath('//*[text()="City Name cannot be more than 56 characters"]'));
this.create_practice1=element(by.xpath('(//*[text()="Create Practice"])[2]'));
this.Practice_Name_already_existing1=element(by.xpath('//*[text()="practice is already existing in system."]'));
this.facilities1=element(by.xpath('//*[@ng-reflect-klass="breadcrumb-item  cursor-defaul"]'));
this.practice_128char_error1=element(by.xpath('//*[text()="Practice Name cannot be more than 128 characters"]'));



//36217
this.practice_type=element(by.xpath("//div[text()=' Practice Type ']"));
this.ASC_tab=element(by.xpath("//span[text()='ASC ASSOCIATIONS']"));
this.Practice_Name_column=element(by.xpath("//div[text()=' Practice Name ']"));
this.Practice_ID_column=element(by.xpath("//div[text()=' Practice Id ']"));
this.practice_type_column=element(by.xpath("//div[text()=' Practice Type ']"));
this.add_more=element(by.xpath("//button[text()=' ASSOCIATE MORE']"));
this.List_of_surgical_centers=element(by.xpath("//h5[text()='List of surgical centers ']"));
this.Previous=element(by.xpath("//button[text()='«Previous']"));
this.Next=element(by.xpath("//button[text()='Next»']"));
this.Associate=element(by.xpath("//button[text()='Associate']"));
this.cross_button=element(by.xpath("//span[text()='×']"));
this.Practice_Type=element(by.xpath("//label[text()=' Practice Type ']"));
this.Practicetype_dropdown=element(by.xpath('//*[@formcontrolname="selectedPracticeType"]'));
this.Practicetype_ASC=element(by.xpath('//*[@formcontrolname="selectedPracticeType"]'));
this.yes_button_2=element(by.xpath("//*[text()='Yes']"));
this.practice_type_dropdown=element(by.xpath("//label[text()=' Practice Type ']"));
this.checkboxasc1=element(by.xpath("(//input[@ng-model='checked'])[1]"));
this.errorascpopup_message=element(by.xpath("//p[text()='Please select one or more ASC/s']"));
//this.okpop_button=element(by.xpath("//button[text()='OK']"));
this.ascsuccess_message=element(by.xpath("//p['ASC Association Successfully']"));
this.checkboxasc2=element(by.xpath("(//input[@name='checked'])[2]"));
this.checkboxasc3=element(by.xpath("(//input[@name='checked'])[3]"));
this.subadri=element(by.xpath("//td[text()='subadri']"));
this.subadri_checkbox=element(by.xpath("//input[@ng-model='checked']"));
this.practiceinfo_tab=element(by.xpath("//span[text()='PRACTICE INFO']"));
this.search_box=element(by.xpath("//input[@placeholder='Search by name']"));
this.Practice_Type1=element(by.xpath("//*[text()=' Practice Type ']"));
this.Practicetype_ASC1=element(by.xpath("//*[text()='ASC']"));

//1458 modifications
this.software_version=element(by.xpath("//small[text()='Software Version cannot be blank']"));
this.software_version_field=element(by.xpath("//input[@placeholder='Software Version']"));

//26813
this.edit=element(by.xpath("//button[text()='EDIT SITENETWORK']"));

//36217
this.amctest=element(by.xpath("//a[@title='AMcTest']"));
this.cross_button=element(by.xpath("(//button[@class='close'])[2]"));
this.merge=element(by.xpath('//*[text()=" MERGE "]'));
this.status=element(by.xpath("//button[text()='MERGE STATUS ']"));
this.Complete_popup=element(by.xpath("//p[text()='Completed']"));
this.checkascbox=element(by.xpath("//span[text()='×']/following::input"));
this.ascpractice=element(by.xpath("//td[text()='AMAscTest']"));
this.surgical_field=element(by.xpath("//input[@placeholder='Search by name']"));

this.dessociate=element(by.xpath("//button[text()=' DISSOCIATE']"));
this.relascpractice=element(by.xpath("//td[text()='relasctest']"));
this.belascpractice=element(by.xpath("//td[text()='belasctest']"));
this.telascpractice=element(by.xpath("//td[text()='telasctest']"));
this.checkboxdsc=element(by.xpath("//table[@class='dhs-table']/tbody[1]/tr[1]/td[4]/input[1]"));
this.checkboxdsc1=element(by.xpath("//table[@class='dhs-table']/tbody[1]/tr[2]/td[4]/input[1]"));
this.checkboxdsc2=element(by.xpath("//table[@class='dhs-table']/tbody[1]/tr[3]/td[4]/input[1]"));
this.dscsuccess_message=element(by.xpath("//p[text()='ASC Dissociated Successfully']"));

//38960
this.practice_info_merge=element(by.linkText('Practice Info'));
this.cross_button=element(by.xpath("(//span[text()='×'])[2]"));
this.merge=element(by.xpath('//*[text()=" MERGE "]'));
this.status=element(by.xpath("//button[text()='MERGE STATUS ']"));
this.provided_pilot_practice_already_merged_with_master_ora_message=element(by.xpath("//*[contains(text(),'The provided pilot practice already merged with master ora')]"));
this.Complete_popup=element(by.xpath("//p[text()='Completed']"));
this.Do_u_want_to_merge_this_practice_to_master_ora=element(by.xpath("//p[text()='Do you want to merge this practice to Master ORA?']"));
this.YES=element(by.xpath("//button[text()='YES']"));
this.regiondrop=element(by.xpath("//select[@ng-reflect-name='selectedRegion']"));
this.countrydrop=element(by.xpath("//select[@ng-reflect-name='selectedCountry']"));
this.statedrop=element(by.xpath("//select[@ng-reflect-name='state']"));

//38959
this.AACRSDHSONEs=element(by.xpath("//*[@id='searchPracticeKey']"));
this.practice_type_Clinic=element(by.xpath("//*[text()='CLINIC']"));
this.AACRSDHSONEs_link=element(by.xpath("//*[text()='AACRSDHSONEs']"));
this.This_Practice_is_not_merged_to_master_ORA=element(by.xpath("//*[text()='This Practice is not merged to master ORA']"));
this.Error_popup=element(by.xpath("//*[text()='ERROR']"));
this.OK_button=element(by.xpath('//*[text()="OK"]'));
this.Merge_status=element(by.xpath('//*[text()="MERGE STATUS "]'));
this.Partial_Complete_status=element(by.xpath('//*[text()="Partial Complete"]'));
this.cross_ASC=element(by.xpath('(//span[text()="×"])[2]'));
this.ASC_Associations_tab=element(by.xpath('//*[text()="ASC ASSOCIATIONS"]'));
this.associate_more=element(by.xpath('//*[text()=" ASSOCIATE MORE"]'));
this.Practice_info=element(by.xpath('//*[text()="Practice Info"]'));
this.Practices=element(by.xpath('//*[text()="Practices"]'));
this.AAPOnePractice=element(by.xpath("//*[@id='searchPracticeKey']"));
this.AAPOnePractice_link=element(by.xpath("//*[text()='AAPOnePractice']"));
this.relascpractice_checkboxdsc= element(by.xpath("(//*[@id='dissociateId'])[1]"));
this.belascpractice_checkboxdsc= element(by.xpath("(//*[@id='dissociateId'])[1]"));
this.telascpractice_checkboxdsc= element(by.xpath("(//*[@id='dissociateId'])[2]"));
this.facility_message=element(by.xpath("//p[text()='Facility Created in DHS Successfully']"));

this.PracName=element(by.xpath("(//label[@for='inputEmail4'])[2]"));
this.facName=element(by.xpath("(//label[@for='inputEmail4'])[2]"));
this.AAPOnePractices=element(by.xpath("(//div[@class='td-ellipsis'])[1]"));

this.Link_practice =element(by.xpath('//*[text()="LINK PRACTICE"]'));
this.link_practice_asc =element(by.xpath("(//*[@ng-reflect-klass = 'myclass'])[1]"));
this.Save_changes= element(by.xpath('//*[text()="Save changes"]'));
this.clinic =  element(by.xpath('//*[@ng-reflect-model="CLINIC"]'));
this.practice_type_clinic =  element(by.xpath('//*[text()="CLINIC"]'));
this.device_serial_number1=element(by.xpath("//*[@placeholder='Device Serial Number']"));
this.PracName=element(by.xpath("(//label[@for='inputEmail4'])[2]"));
this.facName=element(by.xpath("(//label[@for='inputEmail4'])[2]"));
this.AAPOnePractices=element(by.xpath("(//div[@class='td-ellipsis'])[1]"));
this.Ok_flash_message =element(by.xpath("//*[text()='OK']"));
this.data_stored_successfully=element(by.xpath("//p[text()='Data Stored Successfully']"));
//this.okbutton=element(by.xpath("//button[text()='ok']"));
this.restart_successfully=element(by.xpath("//p[text()='Successfully Restarted gateway/s']"));
this.gateway_deleted_successfully=element(by.xpath("//p[text()='Gateway is deleted successfully']"));
this.gateway_deployment_initiated_successfully=element(by.xpath("//p[text()='Gateway deployment initiated successfully']"));
this.gateway_restart_initiated_successfully=element(by.xpath("//p[text()='Gateway restart initiated successfully, Success!']"))
this.facfield=element(by.xpath("(//label[@for='inputEmail4'])[2]"));
this.sapfield=element(by.xpath("(//label[@for='inputEmail4'])[3]"));
this.alconfield=element(by.xpath("//label[text()=' Alcon Ship to Account # ']"));
this.addfield=element(by.xpath("(//label[@for='inputEmail4'])[5]"));
this.addfield2=element(by.xpath("(//label[@for='inputEmail4'])[8]"));
this.cityfield=element(by.xpath("(//label[@for='inputEmail4'])[9]"));
this.zipfield=element(by.xpath("(//label[@for='inputEmail4'])[10]"));
this.cancelbutton=element(by.xpath("//button[text()=' CANCEL ']"));
this.createfacbutton=element(by.xpath("//button[text()=' CREATE FACILITY ']"));
this.facility_creatsuccessfully=element(by.xpath("//p[text()='Facility Created in DHS Successfully']"));
this.okfac=element(by.xpath("(//button[@aria-label='Close'])[3]"));
this.ok=element(by.xpath("//button[text()='OK']"));
this.devicesnotebutton=element(by.linkText('DEVICES'));
this.edgeinfobutton=element(by.xpath("(//span[@ng-reflect-ng-class='[object Object]'])[3]"));
this.sitenet=element(by.xpath("//table[@class='dhs-table']/tbody[1]/tr[2]/td[10]/div[1]/a[1]"));
this.facupsuc=element(by.xpath("//p[text()='Facility Updated in DHS and ORA']"));
this.device_serial_number2=element(by.xpath("//*[@ng-reflect-name='deviceSerialNumber']"));
this.pagination_facilty=element(by.xpath('//*[text()="pagination facility"]'));
this.Toggale1=element(by.xpath('//*[@class="toggle-button-switch"]'));
this.facilty_test=element(by.xpath('//*[text()="facility test"]'));
this.inactive1_status =element(by.xpath('(//div[text()=" Inactive"])[1]'));
this.active1_status =element(by.xpath('(//*[text()=" active"])[1]'));
this.status1_in_inactive=element(by.xpath('//*[text()=" Inactive"]'));
this.status1_in_active=element(by.xpath('//*[text()=" active"]'));
this.yes_button_21=element(by.xpath("//*[text()='YES']"));
this.Apple=element(by.xpath("//*[text()='Apple']"));
this.notes_cross_button=element(by.xpath("(//*[text()='×'])[1]"));
this.PracticeName1=element(by.xpath(" //*[@ng-reflect-name= 'practiceName']"));
this.address=element(by.xpath("//*[@ng-reflect-name= 'userAddress']"));
this.FacilityName1=element(by.xpath(" //*[@ng-reflect-name= 'name']"));
this.facility_address = element(by.xpath(" //*[@ng-reflect-name= 'address1']"));
//14891 re-modifications
this.cancel14891_1= element(by.xpath("//button[text()='CANCEL']"));
//32256 re-modifications
this.AmaTest=element(by.xpath('//*[text()="AMaTest"]'));
this.Abbey_testpracticess=element(by.xpath("//*[text()='Abbey testpracticesss']"));
 //14891 re-modification xpaths
 this.gateway_Type=element(by.xpath("//select[@ng-reflect-name='gatewayType']"));
 //2163 remodification xpaths
 this.facility_Tab_usa=element(by.xpath("(//a[@ng-reflect-ng-class='[object Object]'])[3]"));
 this.AMaTest_facility=element(by.xpath("//a[@title='Facility Details']"));
 this.tsefacility_tab=element(by.xpath("//span[text()='FACILITIES']"));
 this.DEV_DML=element(by.xpath('//*[text()="DEV-DML"]'));
 //42296 
this.AAPPracticeFivy=element(by.xpath("//*[text()='AAPPracticeFivy']"));
this.Clinic_Associations_tab=element(by.xpath("//*[text()='CLINIC ASSOCIATIONS']"));
this.Please_select_one_or_more_CLINICS=element(by.xpath("//*[text()='Please select one or more CLINIC/s']"));
this.ascclinic=element(by.xpath("//*[@id='searchPracticeKey']"));
this.ascclinic_link=element(by.xpath('//*[text()="ascclinic"]'));
this.dissociate=element(by.xpath('//*[text()=" DISSOCIATE"]'));
//this.aclinic=element(by.xpath('//*[text()="aclinic"]'));
this.checkClinicbox=element(by.xpath('//*[@id="exampleCheck1"]'));
this.Clinic_Associated_Successfully=element(by.xpath('//*[text()="CLINIC Associated Successfully"]'));
this.Clinic_Associated_successfully=element(by.xpath('//p[text()="CLINIC Associated Successfully"][1]'));
this.clinicascs=element(by.xpath('//td[text()="clinicascs"]'));
this.CLINICASC=element(by.xpath('//*[text()="CLINICASC"]'));
//this.aclinic_checkboxclinic=element(by.xpath('//input[@id="dissociateId"]'));
this.Clinic_Dissociated_Successfully=element(by.xpath("//*[text()='CLINIC Dissociated Successfully']"));
this.clinicascs_checkboxclinic=element(by.xpath('//*[@id="dissociateId"]'));
this.CLINICASC_checkboxclinic=element(by.xpath('//*[@id="dissociateId"]'));
this.ASC_Association_is_Failed=element(by.xpath('//p[@class="ng-star-inserted"]'));
this.ViswaClinicalPractice=element(by.xpath('//*[@id="SearchValue"]'));
this.ViswaClinicalPractice_checkboxclinic=element(by.xpath("//table[@class='dhs-table']/tbody[1]/tr[1]/td[4]/input[1]"));
this.ViswaClinicalPractice=element(by.xpath('//*[text()="ViswaClinicalPractice"]'));
this.little=element(by.xpath('//*[text()="little"]'));
this.little_checkboxclinic=element(by.xpath("//table[@class='dhs-table']/tbody[1]/tr[2]/td[4]/input[1]"));

this.tseviewpractice_link=element(by.xpath("//a[@title='tseview practice']"));
this.tseviewfacility_link=element(by.xpath("//span[text()='FACILITIES']"));
this.usafacilitypractice_link=element(by.xpath("//a[@title='usafacility']"));
this.usafacility_link=element(by.xpath("//span[text()='FACILITIES']"));
this.associate_button_clinics=element(by.xpath('//button[@type="button" and text()="Associate"]'));

//1255 re-re-modif
this.tseviewpractice_link_change=element(by.xpath("//a[@title='tseview practice']"));
//26813 re-re-modif
this.dataOK_button=element(by.xpath("//button[text()='OK']"));
//1255 re-re-modif
this.tseviewpractice_link_change=element(by.xpath("//a[@title='tseview practice']"));
this.tseviewlistdevice=element(by.xpath("//span[text()='DEVICES']"));

//42296 re-re-modif
this.associate_button_clinic=element(by.xpath("//button[text()='Associate']"));
this.CLINIC_Association_is_Failed=element(by.xpath('//p[@class="ng-star-inserted"]'));
//36217 re-re-modif
this.link_asc_practice_button=element(by.xpath("//button[text()='LINK PRACTICE']"));

this.data_stored_popup=element(by.xpath("//p[text()='Data Stored Successfully']"));
this.error_clinic_msg=element(by.xpath("//p[text()='Please select one or more CLINIC/s']"));
// 32221
this.Data_Stored_Successfully=element(by.xpath('//p[text()="Data Stored Successfully"]'));
this.Are_you_sure_do_you_want_to_Restart_Gateways=element(by.xpath('//p[text()="Are you sure do you want to Restart Gateway/s ?"]'));
this.NO=element(by.xpath('//button[text()="NO"]'));
this.DELETE=element(by.xpath('//button[text()="DELETE "]'));
this.Are_you_sure_you_want_to_delete_device=element(by.xpath('//p[text()="Are you sure you want to delete device?"]'));
this.Yes_DELETE=element(by.xpath('//button[text()="Yes"]'));
this.Alaska_caree_Test_links=element(by.xpath("//a[@title='Alaska caree Test']"));
this.edit_device_button=element(by.xpath("(//button[text()='Edit '])[2]"));


// 42296 re-modifications
this.asc_clinic=element(by.xpath("//a[@title='ascclinic']"));
this.clinic_tab=element(by.xpath("//span[text()='CLINIC ASSOCIATIONS']"));
this.associatemore_button=element(by.xpath("//button[text()=' ASSOCIATE MORE']"))
this.OK_popup_button=element(by.xpath("//button[text()='OK']"));
this.dissociate_button=element(by.xpath("//button[text()=' DISSOCIATE']"));
this.clinicasc_checkbox=element(by.xpath("(//table[@class='table']//input)[1]"));
this.clinic_associated_success_message=element(by.xpath("//p[text()='CLINIC Associated Successfully']"));
this.viswaclinic_checkbox=element(by.xpath("(//span[text()='×']/following::input)[1]"));
this.clinicasc_dissociate_checkbox=element(by.xpath("(//input[@id='dissociateId'])[1]"));
this.clinic_dissociated_successmessage=element(by.xpath("//p[text()='CLINIC Dissociated Successfully']"));
this.viswaclinic_dissociate_checkbox=element(by.xpath("(//input[@id='dissociateId'])[1]"));

//Data stored popup re-modifications
this.Data_stored=element(by.xpath("//p[text()='Data Stored Successfully']"));

 
this.devicetype=element(by.xpath("select[ng-reflect-name='deviceType']"));

//unconfigured sitenetwork xpaths
this.edgeid_field=element(by.xpath("//input[@placeholder='Edge Id']")); 

this.gateway_field=element(by.xpath("//select[@formcontrolname='gatewayType']"));
this.device_manufacture_field=element(by.xpath("(//input[@placeholder='Device Manufacturer'])[2]"));
this.device_manufact_field=element(by.xpath("//input[@placeholder='Device Manufacturer']"));
this.edit_device_manufact_field=element(by.xpath("(//input[@placeholder='Device Manufacturer'])[1]"));

this.device_field=element(by.xpath("//select[@formcontrolname='deviceType']"));
this.edgeid_524value=element(by.xpath('//*[text()="edge561"]'));
this.edgeid_520value=element(by.xpath('//*[text()="edge15"]'));
this.edgeid_14value=element(by.xpath('//*[text()="edge14"]'));
this.edgeid_523value=element(by.xpath("//*[text()='edge560']'"));
this.edge_info_attachment=element(by.xpath("//span[text()='EDGE INFO']"));
this.edge_id_1256=element(by.xpath('//*[text()="12ab-1256-1256"]'));

this.save_configure_sitenetwork=element(by.xpath("//button[text()='Save Configure Site Network']"));
this.edgeid_52value=element(by.xpath('//*[text()="edge56"]'));
this.edgeid_426value=element(by.xpath('//*[text()="edge23"]'));
 
this.device_serial_field=element(by.xpath("//input[@formcontrolname='deviceSerialNumber']"));
this.edit_serial_field=element(by.xpath("(//input[@formcontrolname='deviceSerialNumber'])[1]"));
this.edit_button=element(by.xpath("//button[text()='Edit']"));
this.navigate_back=element(by.xpath("(//a[@id='breadcrumbs1'])[1]"));
this.Ok_gateways=element(by.xpath('//button[@class="btn btn-primary" and text()="OK"]'));
this.delete_button=element(by.xpath("//button[text()='DELETE ']"));

//Non-regression User Stories
this.practice_name_field=element(by.xpath("//input[@formcontrolname='practiceName']"));

// this.practice_name_field=element(by.xpath("input[@id="practiceName" and "))
    //input[@id="practiceName" and @ng-reflect-name="practiceName"]
this.Region_field=element(by.xpath("//select[@formcontrolname='selectedRegion']"));

this.edgeid_400value=element(by.xpath('//*[text()="edge500"]'));
this.edgeid_401value=element(by.xpath('//*[text()="edge400"]'));
this.delete_button=element(by.xpath("//button[text()='DELETE ']"));

this.facility_tab_button=element(by.xpath("//span[text()='FACILITIES']"));
this.edgeid_150value=element(by.xpath('//*[text()="edge152"]'));
this.edgeid_015value=element(by.xpath('//*[text()="edge015"]'));
this.save_change=element(by.xpath("//button[text()='Save changes']"));

this.link_path=element(by.xpath("(//div[@class='container ng-star-inserted']//p)[2]"));
this.save_change=element(by.xpath("//button[text()='Save changes']"));
this.save_button=element(by.xpath("//button[text()=' SAVE ']"));
this.link_link_path=element(by.xpath("(//div[@class='container ng-star-inserted'])[5]"));
this.link_link_paths=element(by.xpath("(//div[@class='container ng-star-inserted'])[4]"));
this.link_link_pats=element(by.xpath("(//div[@class='container ng-star-inserted'])[3]"));
this.link_asc_path=element(by.xpath("(//div[@class='container ng-star-inserted'])[6]"));

this.link_asc_s_path=element(by.xpath("(//div[@class='container ng-star-inserted'])[7]"));

this.practice_info_link_button=element(by.xpath("//button[text()=' LINK PRACTICE ']"));
this.displayname_field=element(by.xpath("//input[@formcontrolname='deviceDisplayName']"));
this.storageAE_textbox_field=element(by.xpath("(//input[@formcontrolname='storageAETitle'])[1]"));
this.storageAE_port_field=element(by.xpath("(//input[@formcontrolname='storagePort'])[1]"));
this.worklistAETitle_field=element(by.xpath("(//input[@formcontrolname='worklistAETitle'])[1]"));
this.worklistAEport_field=element(by.xpath("(//input[@formcontrolname='worklistPort'])[1]"));


this.Abcpractices_link=element(by.xpath("//a[@title='Abcpractices']"));
// this.Abcpractices=element(by.xpath("//input[@placeholder='Search Practices']"));
this.Anapple_link=element(by.xpath("//a[@title='Anapple']"));
this.Anapple=element(by.xpath("//*[@id='searchPracticeKey']"));
this.Abcpractices=element(by.xpath("//*[@id='searchPracticeKey']"));
this.ajayclinic_link=element(by.xpath("//a[@title='AjayClinic']"));
this.ajayclinic=element(by.xpath("//*[@id='searchPracticeKey']"));
this.aprtesting_link=element(by.xpath("//a[@title='APRTESTING']"));
this.aprtesting=element(by.xpath("//*[@id='searchPracticeKey']"));
this.Aronpractice_link=element(by.xpath("//a[@title='Aaron practice']"));
this.Aronpractice=element(by.xpath("//*[@id='searchPracticeKey']"));
this.test_facility=element(by.xpath('//*[text()="testFacility"]'));
this.acm_link=element(by.xpath("//a[@title='AccM']"));
this.acm=element(by.xpath("//*[@id='searchPracticeKey']"));
this.myratestpractices_link=element(by.xpath("//td[text()='Myra testpracticesss']"));
this.cloudypractice_link=element(by.xpath("//a[@title='Cloyd practice']"));
this.cloudypractice=element(by.xpath("//*[@id='searchPracticeKey']"));


this.AlconNewdeonpractice_link=element(by.xpath("//a[@title='AlconNewdeon']"));
this.AlconNewdeonpractice=element(by.xpath("//*[@id='searchPracticeKey']"));
this.myratestpractices_link=element(by.xpath("//td[text()='Myra testpracticesss']"));
this.myratestpractices_checkbox=element(by.xpath("//input[@ng-model='checked']"));
this.myratestpractices=element(by.xpath('//*[@id="SearchValue"]'));
this.pallavi_link=element(by.xpath("//a[@title='PallaviPractice']"));
this.pallavi_practice=element(by.xpath("//*[@id='searchPracticeKey']"));
this.pallavi_facility=element(by.xpath('//*[text()="PallaviPractice"]'));
this.pallavi_practice_id=element(by.xpath('//*[text()="28cb9ef3-155b-4f30-9a0f-07a52428f591"]'));
this.testing_pallavi_practice_link=element(by.xpath("//a[@title='TestingpallaviPractice']"));
this.testing_pallavi_practice=element(by.xpath("//*[@id='searchPracticeKey']"));
this.testing_pallavi_facility=element(by.xpath('//*[text()="Testingpallavifacility"]'));
this.Amruthasc_checkbox=element(by.xpath("//input[@ng-model='checked']"));
this.Amruthasc=element(by.xpath('//*[@id="SearchValue"]'));
this.Amruthasc_link=element(by.xpath("//a[@title='Amruthasc']"));
this.testing_pallavi_practice_id=element(by.xpath('//*[text()="121b2550-6c83-40f1-89f6-bef9c7f36508"]'));
this.camlinpen_facility=element(by.xpath('//*[text()="camlinpen"]'));
this.amruthpractice_link=element(by.xpath("//a[@title='Amruthpracticeasc']"));
this.amruthpractice=element(by.xpath("//*[@id='searchPracticeKey']"));

this.link_acm_hospital=element(by.xpath("//div[@class='container ng-star-inserted']//p[1]"));
this.califor_link=element(by.xpath("(//div[@class='container ng-star-inserted']//p)[3]"));
this.browser=element(by.xpath("(//div[@class='container ng-star-inserted']//p)[1]"));
this.barbieuser_link=element(by.xpath("(//div[@class='container ng-star-inserted']//p)[2]"));
this.duelpractice_link=element(by.xpath("//div[@class='container ng-star-inserted']//p[1]"));
this.due=element(by.xpath("//input[@placeholder='Search by name']"));
this.asccommand_link=element(by.xpath("//div[@class='container ng-star-inserted']//p[1]"));
this.command_link=element(by.xpath("//div[@class='container ng-star-inserted']//p[1]"))
this.cherry_link=element(by.xpath("//div[@class='container ng-star-inserted']//p[4]"))
this.brot=element(by.xpath("(//div[@class='container ng-star-inserted']//p)[1]"));
this.Fritz_testpractices=element(by.xpath("//td[text()='Fritz testpractices']"));

this.facility_checkbox_field=element(by.xpath("(//input[@type='checkbox'])[2]"));
this.facility_field=element(by.xpath("//input[@placeholder='Facility Name']"));
this.sap_field=element(by.xpath("//input[@formcontrolname='sapSoldToAccount']"));
this.alcon_field=element(by.xpath("//input[@formcontrolname='alconShipToAccountNumber']"));
this.address_field=element(by.xpath("//input[@formcontrolname='address1']"));
this.city_field=element(by.xpath("//input[@formcontrolname='city']"));
this.zip_field=element(by.xpath("//input[@formcontrolname='zipcode']"))
this.save_configure_button=element(by.xpath("//button[text()='Save Configure Site Network']"));

this.new_oradevice_device_serial_number_values=element(by.xpath('//*[text()="dmllennsxtest12334"]')); 
this.new_oradevice_device_serial_number_valuess=element(by.xpath('//*[text()="dmllennsxtest123345"]'));
this.myratestpractices_checkboxs=element(by.xpath('//input[@id="exampleCheck1" and @type="checkbox"]'));
this.new_oradevice_device_serial_numbers_valuess=element(by.xpath('//*[text()="dmllennsxtest1233456"]'));
this.practice_information_button=element(by.xpath("(//a[@id='breadcrumbs1'])[2]"));

this.device_asc=element(by.xpath("//*[@id='searchPracticeKey']"));
this.deviceasc_link=element(by.xpath('//a[@title="deviceasc"]'));
this.device_ascf=element(by.xpath('//*[text()="deviceascf"]'));


};

module.exports = new Elements();