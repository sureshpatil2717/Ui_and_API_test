"use strict";
var log4js = require('log4js');
var logger = log4js.getLogger();
const { Given, Then, When } = require('cucumber');
const utils = require('../../Page_Objects/Generic_Methods/utils.js');
const login = require('../../Page_Objects/Generic_Methods/login.js');
const data =require('../../Test_Data/global_input.json');

var chai=require('chai');
chaiHttp = require('chai-http');
chai.use(chaiHttp);
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);

const { protractor } = require('protractor');
var {setDefaultTimeout} = require('cucumber');
setDefaultTimeout(200 * 1000);

const path = require('path');
const yaml = require('js-yaml');
const fs   = require('fs');
const EC = protractor.ExpectedConditions;
const expect = chai.expect;
// const app=require('express')();
const { Pool } = require('pg');
const R = require('ramda');



Given(/^I should delete practice configuration for "([^"]*)" and "([^"]*)" and "([^"]*)"$/ , async function(value1,value2,value3){
   
    await login.getVaultToken();
    await login.getDataFromVault();
    const pool = new Pool({
        "jdbc":"postgresql",
        "host":"127.0.0.1",
        "port":"12337",
        "user":global.dbuser,
        "password":global.dbpassword,
        "database":"hsdp_pg",
        "sslmode":"disable"
        
        })
		try{
 pool.connect();
 const selectdata=data[value3] 
 //const selectres=await pool.query(selectdata);
 //var res=JSON.stringify(selectres.rows[0].id);
//const deletesq="DELETE FROM tbl_sitesurvey_devices where gateway_id='"+res+"'"
var deletegq=data[value1];
 var deletepq=data[value2];
 var deletesq=data[value3];
 const d=await pool.query(deletesq);
 const deletegres=await pool.query(deletegq);
 const deleteqres=await pool.query(deletepq);

 pool.end();
 
 browser.sleep(6000);
 } catch(e){
    logger.error('db ' + e.message);
  }
    

});
When(/^I insert devices data "([^"]*)"$/,async function(object){

    await login.getVaultToken();
    await login.getDataFromVault();

    const pool = new Pool({
        "jdbc":"postgresql",
        "host":"127.0.0.1",
        "port":"12337",
        "user":global.dbuser,
        "password":global.dbpassword,
        "database":"hsdp_pg",
        "sslmode":"disable"
        
        })
 

var insertdata=data[object];
var requestbody=JSON.stringify(data["cerner_device_response"]);
var replaceclientid=requestbody.replace("valutclientid",global.deviceClientId);
var replaceclientsecret=replaceclientid.replace("valutclientsecret",global.deviceClientSecret);
var replacedevicelogin=replaceclientsecret.replace("valutloginid",global.deviceLoginId);
var replacedevicepwd=replacedevicelogin.replace("valutpswd",global.devicePwd)
var replaceinsertdata=insertdata.replace("responsedata",replacedevicepwd);
var requestbody=JSON.stringify(data["cerner_device_response2"]);
var replacedevicelogin=replaceclientsecret.replace("valutloginid",global.deviceLoginId2);
var replacedevicepwd=replacedevicelogin.replace("valutpswd",global.devicePwd2)
var replaceinsertdata=insertdata.replace("responsedata",replacedevicepwd);

try{
 pool.connect();
 const instervalue=await pool.query(replaceinsertdata);
 pool.end();
 } catch(e){
    logger.error('db ' + e.message);
  }

});

When('I get browsername',async function(){

   
    logger.error(browserName);

});
When(/^I should see device information of "([^"]*)"$/,async function(object){

    await login.getVaultToken();
    await login.getDataFromVault();

    const pool = new Pool({
        "jdbc":"postgresql",
        "host":"127.0.0.1",
        "port":"12337",
        "user":global.dbuser,
        "password":global.dbpassword,
        "database":"hsdp_pg",
        "sslmode":"disable"
        
        })
		try{
pool.connect();

var selectq=data[object];
const selectdata=await pool.query(selectq);
var time=JSON.stringify(selectdata.rows);

pool.end();

} catch(e){
    logger.error('db ' + e.message);
  }

});

When(/^I delete the device from "([^"]*)"$/, async function(object){
   
    await login.getVaultToken();
    await login.getDataFromVault();

    const pool = new Pool({
        "jdbc":"postgresql",
        "host":"127.0.0.1",
        "port":"12337",
        "user":global.dbuser,
        "password":global.dbpassword,
        "database":"hsdp_pg",
        "sslmode":"disable"
        
        });
		try{
        pool.connect();
        var deleteq=data[object];
        const selectdata=await pool.query(deleteq);
        pool.end();
		} catch(e){
    logger.error('db ' + e.message);
  }
      
});

When('I delete registered device with hsdpid',async function(){
   
    await login.getVaultToken();
    await login.getDataFromVault();

    const pool = new Pool({
        "jdbc":"postgresql",
        "host":"127.0.0.1",
        "port":"12337",
        "user":global.dbuser,
        "password":global.dbpassword,
        "database":"hsdp_pg",
        "sslmode":"disable"
        
        });
		try{
        pool.connect();
        
        var del="DELETE FROM tbl_heartbeat where device_hsdp_Id= '"+global.HSDPID+"'"
        var register="DELETE FROM tbl_registered_devices where device_hsdp_Id= '"+global.HSDPID+"'"
        const dele=await pool.query(del)
        const selectdata=await pool.query(register);
        pool.end();
		} catch(e){
    logger.error('db ' + e.message);
  }
      
});