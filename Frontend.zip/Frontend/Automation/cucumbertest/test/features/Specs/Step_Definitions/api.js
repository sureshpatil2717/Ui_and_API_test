"use strict";
var log4js = require('log4js');
var logger = log4js.getLogger();
const { Given, Then, When } = require('cucumber');
const utils = require('../../Page_Objects/Generic_Methods/utils.js');
const login = require('../../Page_Objects/Generic_Methods/login.js');
const elements=require('../../Page_Objects/Elements_Contains/Elements.js');
const data = require('../../Test_Data/global_input.json');
var chai=require('chai');
chaiHttp = require('chai-http');
chai.use(chaiHttp);
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
const { protractor } = require('protractor');
const path = require('path');
const yaml = require('js-yaml');
const fs   = require('fs');
const EC = protractor.ExpectedConditions;
const expect = chai.expect
var settime=utils.setTimeout();

When('I call Access Token Post API', async function() {
    const expect = chai.expect;
  
    try{
      await login.getVaultToken();
      await login.getDataFromVault();
      var tokenCreation = JSON.stringify(global.AuthTokenCreationPayload);
      await utils.postMethod(data["access_token_IP"], data["access_token_creation_Path"], JSON.parse(tokenCreation)).then(function(response){
      global.accessToken = response.body.access_token;
      global.response = response;
  
    });
  } catch(e){
    logger.error('Error while App Initializing' + e.message);
  }
  }); 

Then('I should get Success Status Code', function(){
    try{
    expect(global.status).to.equal("200");
  } catch(e){
    logger.error('Error while App Initializing' + e.message);
  }
  });
  
Then('I should get valid Access Token', function(){
    try{
    expect(global.accessToken).to.not.equal(null);
  } catch(e){
    logger.error('Error while App Initializing' + e.message);
  }
  });  

  // When('I call Access Token Introspect Post API', async function() {
  //   const expect = chai.expect;
  //   var tokenIntrospect = {
  //     "token": global.accessToken
  //   }
  //   try{
  //   await utils.postMethod(data["access_token_IP"], data["access_token_introspect_Path"], tokenIntrospect).then(function(response){
  //     global.response = response;
  
  //   });
  // } catch(e){
  //   logger.error('Error while App Initializing' + e.message);
  // }
  // });
  
  When('I call Region Get API', async function() {
    const expect = chai.expect;
    try{
    await utils.getMethod(data["region_IP"], data["region_Path"], global.accessToken).then(function(response){
      global.response = response;
  
    });
  } catch(e){
    logger.error('Error while App Initializing' + e.message);
  }
  });
  
  When(/^I call "([^"]*)" Region Get API$/, async function(Region) {
    const expect = chai.expect;
    try{
    await utils.getMethod(data["region_IP"], data["region_Path"]+ '/' + data[Region], global.accessToken).then(function(response){
      global.response = response;
    });
  } catch(e){
    logger.error('Error while App Initializing' + e.message);
  }
  });
  
  When('I call Countries Get API', async function() {
    const expect = chai.expect;
    try{
    await utils.getMethod(data["country_IP"], data["country_Path"], global.accessToken).then(function(response){
  
    });
  } catch(e){
    logger.error('Error while App Initializing' + e.message);
  }
  });
  
  When('I call Practices Get API', async function() {
    const expect = chai.expect;
    try{
    await utils.getMethod(data["practice_IP"], data["practice_Path"], global.accessToken).then(function(response){
      global.response = response;
    }); 
  } catch(e){
    logger.error('Error while App Initializing' + e.message);
  }
  });

  When('I call Update Connectivity status Update API', async function() {
    const expect = chai.expect;
     global.CurrentTime=await utils.currentdateAndtime();
    
     var UpdateConnectivityStatusPayload = [
                {
                    "deviceHsdpId": global.HSDPID,
                    "connectivitystatustimeDate": global.CurrentTime,
                }
            ]
    try{
      await login.devicetokenfunc();
            await utils.putMethodWithToken(data["Update_Connectivity_Status_IP"], data["Update_Connectivity_Status_Path"], UpdateConnectivityStatusPayload,global.devicetoken).then(function(response){
              const st=response.status;
              // logger.error(JSON.stringify(response))
            global.status=JSON.stringify(st)
            });
              } catch(e){
            logger.error('Error while App Initializing' + e.message);
          }
    });
    
Given('I should get the bootstarp token by calling bootstarp API', async function(){
  try{

    const expect = chai.expect;

      await login.getVaultToken();

      await login.getDataFromVault();

      // console.log(global.bootstarpClientId)

      // console.log(global.bootstrapClientSecret)

      const val= "grant_type=client_credentials&scope="

      // console.log(val)

     // to change str to encodeURIComponent

     // console.log(encodeURIComponent("grant_type=client_credentials&scope="))

     //to to change str to encodeURI format

    // console.log(encodeURI("grant_type=client_credentials&scope="));

   await utils.postMethodwithcontenttypeHeader(data["bootstrap_token_creation_ip"], data["bootstrap_token_creation_path"],encodeURI("grant_type=client_credentials&scope=")).then(function(response){

    const st=response.status;

    global.status=JSON.stringify(st)

    // console.log(global.status)

    global.bootstarptoken = response.body.access_token;

    // console.log(global.bootstarptoken)

   });

   } catch(e){

    console.log('Error while App Initializing' + e.message);

       }

  });


    
    When(/^I run register list of device API for "([^"]*)"$/,   async function(practiceId) {
      const expect = chai.expect;
    const random="iolmaster"+await utils.getRandomInt(1,1000);
    const token="Bearer "+  global.bootstarptoken;        
    var requestbody=JSON.stringify(data["CreateIdentity_creation_payload"]);
    var replacedData=requestbody.replace("serialnum",random);
    var replacePracticeId=replacedData.replace("0fa1c2a1-7b4e-4462-866a-32e2eb98f661",data[practiceId]);

try{
    await utils.postMethodwithHeaders(data["Identity_creation_IP"], data["Identity_creation_Path"], token, JSON.parse(replacePracticeId)).then(function(response){
      const st=response.status;
      global.status=JSON.stringify(st)
      global.registerDeviceresponse=response;
    global.registerDeviceresponseBody=response.body;
    global.clientId = response.body.parameter[9].valueString;
global.clientSecretId = response.body.parameter[10].valueString;
global.LoginID = response.body.parameter[11].valueString;
global.password = response.body.parameter[12].valueString;
global.HSDPID = response.body.parameter[13].valueString;

    
        });
        } catch(e){
          logger.error('Error while App Initializing' + e.message);
        }
    
    });

    When(/^I run register list of device API for "([^"]*)" "([^"]*)" "([^"]*)"$/,   async function(facilityId, practiseId, practiseName) {
      const expect = chai.expect;
    const random="iolmaster"+await utils.getRandomInt(1,1000);
    const token="Bearer "+  global.bootstarptoken; 
    // console.log(token);      
    var requestbody=JSON.stringify(data["CreateIdentity_creation_payload"]);
    var replacedData=requestbody.replace("serialnum",random);
    var replacedData=replacedData.replace("practice_id",data[practiseId]);
    var replacedData=replacedData.replace("practice_name",data[practiseName]);
    var replacePracticeId=replacedData.replace("0fa1c2a1-7b4e-4462-866a-32e2eb98f661",data[facilityId]);
    console.log(requestbody);

try{
	global.HSDPID = '';
    await utils.postMethodwithHeaders(data["Identity_creation_IP"], data["Identity_creation_Path"], token, JSON.parse(replacePracticeId)).then(function(response){
      const st=response.status;

      global.status=JSON.stringify(st)
       console.log(global.status);
      global.registerDeviceresponse=response;
       console.log(global.registerDeviceresponse);
    global.registerDeviceresponseBody=response.body;
    console.log(registerDeviceresponseBody);
    global.clientId = response.body.parameter[10].valueString;
global.clientSecretId = response.body.parameter[11].valueString;
global.LoginID = response.body.parameter[12].valueString;
global.password = response.body.parameter[13].valueString;
global.HSDPID = response.body.parameter[14].valueString;

    
        });
        } catch(e){
          logger.error('Error while App Initializing' + e.message);
        }
    
    });

When(/^I run register list of device API for "([^"]*)" "([^"]*)" "([^"]*)" "([^"]*)"$/, async function (facilityId, practiseId, practiseName, serialNumber) {
  const expect = chai.expect;
  const token = "Bearer " + global.bootstarptoken;
  var requestbody = JSON.stringify(data["CreateIdentity_creation_payload2"]);
  var replacedData = requestbody.replace("serialnum", data[serialNumber]);
  var replacedData = replacedData.replace("practice_id", data[practiseId]);
  var replacedData = replacedData.replace("practice_name", data[practiseName]);
  var replacePracticeId = replacedData.replace("0fa1c2a1-7b4e-4462-866a-32e2eb98f661", data[facilityId]);

  try {
    global.HSDPID = '';
    await utils.postMethodwithHeaders(data["Identity_creation_IP"], data["Identity_creation_Path"], token, JSON.parse(replacePracticeId)).then(function (response) {
      const st = response.status;
      global.status = JSON.stringify(st)
      global.registerDeviceresponse = response;
      global.registerDeviceresponseBody = response.body;
      global.clientId = response.body.parameter[9].valueString;
      global.clientSecretId = response.body.parameter[10].valueString;
      global.LoginID = response.body.parameter[11].valueString;
      global.password = response.body.parameter[12].valueString;
      global.HSDPID = response.body.parameter[13].valueString;

    });
  } catch (e) {
    logger.error('Error while App Initializing' + e.message);
  }

});
    
When(/^I call Log Message create Post API with "([^"]*)"$/, async function(value) {
          const expect = chai.expect;
          const log_message=data[value]
      var LogMessageCreation = {
              "log": log_message
              }
        try{
        await login.devicetokenfunc();
          await utils.postMethodWithToken(data["Log_creation_IP"], data.Log_creation_Path[0]+global.HSDPID+data.Log_creation_Path[1],LogMessageCreation,global.devicetoken).then(function(response){
            global.response = response;
            const st=response.status;
            global.status=JSON.stringify(st)
            
      
        });
      } catch(e){
         logger.error('Error while Creating Log Message' + e.message);
      }
      }); 
	  
	When(/^I call Log Message create Post API "([^"]*)" times with "([^"]*)"$/, async function(num,message) {
            const expect = chai.expect;        
const log_message=data[message]
var LogMessageCreation = {
        "log": log_message
        }
  try{
  var i; var len=num;
for (i = 0; i <len; i++) {
 
  await login.devicetokenfunc();
    await utils.postMethodWithToken(data["Log_creation_IP"], data.Log_creation_Path[0]+global.HSDPID+data.Log_creation_Path[1],LogMessageCreation,global.devicetoken).then(function(response){
      global.response = response;
      const st=response.status;
      global.status=JSON.stringify(st)
      
      

  });


      }
        } catch(e){
          logger.error('Error while Creating Log Message' + e.message);
        }
        });   
	  
    
      

        //for newly created practice 
When(/^I run register list of device API for created practice$/,async function() {
    const expect = chai.expect;
    const random="iolmaster"+await utils.getRandomInt(1,1000);
    // login.bootstarptokenfunc();
    const token="Bearer "+  global.bootstarptoken;  
         
    var requestbody=JSON.stringify(data["CreateIdentity_creation_payload"]);
    var replacedData=requestbody.replace("serialnum",random);
    var replacePracticeId=replacedData.replace("0fa1c2a1-7b4e-4462-866a-32e2eb98f661",global.practiceId);
    

try{
  
await utils.postMethodwithHeaders(data["Identity_creation_IP"], data["Identity_creation_Path"], token, JSON.parse(replacePracticeId)).then(function(response){
  const st=response.status;
  global.status=JSON.stringify(st)
  global.registerDeviceresponse=response;
global.registerDeviceresponseBody=response.body;

global.clientId = response.body.parameter[10].valueString;
global.clientSecretId = response.body.parameter[11].valueString;
global.LoginID = response.body.parameter[12].valueString;
global.password = response.body.parameter[13].valueString;
global.HSDPID = response.body.parameter[14].valueString;


    });
    } catch(e){
      logger.error('Error while App Initializing' + e.message);
    }

});

When(/^I run register list of device API for created facility$/,async function() {
 const expect = chai.expect;
    const random="iolmaster"+await utils.getRandomInt(1,1000);
    // login.bootstarptokenfunc();
    const token="Bearer "+  global.bootstarptoken;    

    var requestbody=JSON.stringify(data["CreateIdentity_creation_payload"]);
    var replacedData=requestbody.replace("serialnum",random);
    var replacedData=replacedData.replace("practice_id",global.practiceId);
    var replacedData=replacedData.replace("practice_name",global.practiceName);
var replacePracticeId=replacedData.replace("0fa1c2a1-7b4e-4462-866a-32e2eb98f661",global.facilityId);

try{
  global.HSDPID='';
await utils.postMethodwithHeaders(data["Identity_creation_IP"], data["Identity_creation_Path"], token, JSON.parse(replacePracticeId)).then(function(response){
  const st=response.status;
  global.status=JSON.stringify(st)
  global.registerDeviceresponse=response;
global.registerDeviceresponseBody=response.body;

global.clientId = response.body.parameter[10].valueString;
global.clientSecretId = response.body.parameter[11].valueString;
global.LoginID = response.body.parameter[12].valueString;
global.password = response.body.parameter[13].valueString;
global.HSDPID = response.body.parameter[14].valueString;


});
} catch(e){
  logger.error('Error while App Initializing' + e.message);
}

});
When('I call Access Token Introspect Post API', async function() {
  const expect = chai.expect;
  // var tokenIntrospect = {
  //   "token": global.AuthTokenCreationPayload
  // }
  await login.getVaultToken();
        await login.getDataFromVault();
        logger.error(JSON.stringify(global.AuthTokenCreationPayload))
  try{
  await utils.postMethod(data["access_token_IP"], data["access_token_creation_Path"], global.AuthTokenCreationPayload).then(function(response){
    global.response = response;
    logger.error(response)

  });
} catch(e){
  logger.error('Error while App Initializing' + e.message);
}
});
When(/^I call Log Message create Post API "([^"]*)" times with "([^"]*)" with "([^"]*)"$/, async function(num,message,Transaction) {
  const expect = chai.expect;        
const log_message=data[message]
const TransactionID=data[Transaction]

var LogMessageCreation = {
      "log": log_message,
  "transactionId":TransactionID
      }
  try{
var i; var len=num;
for (i = 0; i <len; i++) {

await login.devicetokenfunc();
    await utils.postMethodWithToken(data["Log_creation_IP"], data.Log_creation_Path[0]+global.HSDPID+data.Log_creation_Path[1],LogMessageCreation,global.devicetoken).then(function(response){
      global.response = response;
const st=response.status;
global.status=JSON.stringify(st)



  });


}
  } catch(e){
    logger.error('Error while Creating Log Message' + e.message);
  }
});   

