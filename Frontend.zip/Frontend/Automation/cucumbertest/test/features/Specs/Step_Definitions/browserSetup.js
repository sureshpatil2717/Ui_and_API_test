"use strict";
var log4js = require('log4js');
var logger = log4js.getLogger();
const { Given, Then, When } = require('cucumber');
const utils = require('../../Page_Objects/Generic_Methods/utils.js');
const login = require('../../Page_Objects/Generic_Methods/login.js');
// const loginElements = require('../../Page_Objects/Elements_Contains/login_elements.js');
// const practiceElements = require('../../Page_Objects/Elements_Contains/region_country_practices_elements.js');
//const createElements =  require('../../Page_Objects/Elements_Contains/createSiteNetwork_elements.js');
const data = require('../../Test_Data/global_input.json');
var chai=require('chai');
chaiHttp = require('chai-http');
chai.use(chaiHttp);
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
const { protractor, browser } = require('protractor');
const path = require('path');
const yaml = require('js-yaml');
const fs   = require('fs');
const EC = protractor.ExpectedConditions;
const expect = chai.expect;
var settime=utils.setTimeout();

Given(/^I go to the "([^"]*)"$/, async function(appUrl) {
    await utils.appInitialization(data["app_url"]);
    browser.sleep(15000);
});

Given(/^I go to "([^"]*)"$/, function(_site, callback) {
    utils.appInitialization(data["app_url"]).then(callback);
   browser.sleep(15000); 
  });
  Given('I refresh the page', async function() {
	  try{
    browser.refresh();
    browser.sleep(6000);
    }catch(e){
      
       logger.error('Error while clicking' + e.message);
       expect.fail("Error while clicking" +  e.message);
      }
  });

