"use strict";

var log4js = require('log4js');

var logger = log4js.getLogger();

const { Given, Then, When } = require('cucumber');

const utils = require('../../Page_Objects/Generic_Methods/utils.js');

const login = require('../../Page_Objects/Generic_Methods/login.js');

const elements=require('../../Page_Objects/Elements_Contains/Elements.js');

const data = require('../../Test_Data/global_input.json');

var chai=require('chai');

chaiHttp = require('chai-http');

chai.use(chaiHttp);

var chaiAsPromised = require('chai-as-promised');

chai.use(chaiAsPromised);

const { protractor, browser, element } = require('protractor');

const path = require('path');

const yaml = require('js-yaml');

const fs   = require('fs');

const EC = protractor.ExpectedConditions;

const expect = chai.expect

var faker = require('faker');

const { Console } = require('console');

var settime=utils.setTimeout();

 

When('I enter username in username field in login page',async function() {

    try {

        await login.getVaultToken();

        await login.getDataFromVault();

        expect(await elements.username.isPresent()).to.be.true;

        elements.username.clear();

        elements.username.sendKeys(global.ServiceUIUser);

 

    } catch (e) {

        logger.error('Error while App Initializing' + e.message);

        expect.fail("Error while enter username" + e.message);

    }

});

 

When('I enter password in password field in login page',async function() {

    try{

        expect(await elements.password.isPresent()).to.be.true;

        elements.password.clear();

        elements.password.sendKeys(global.ServiceUIPassword);

 

    }

    catch (e) {

        logger.error('Error while App Initializing' + e.message);

        expect.fail("Error while enter password" + e.message);

    }

});

 

When('I enter TSEusername in username field in login page', async function() {

  try{

    expect(await elements["username"].isPresent()).to.be.true;

    await login.getVaultToken();

    await login.getDataFromVault();

  await  elements["username"].sendKeys(global.ServiceUInewTSEUser);

  } catch(e){

    logger.error('Error while App Initializing' + e.message);

    expect.fail("Error while enter username" + e.message);

  }

});

When('I enter TSAusername in username field', async function() {

  try{

    expect(await elements["username"].isPresent()).to.be.true;

    await login.getVaultToken();

    await login.getDataFromVault();

  await  elements["username"].sendKeys(global.ServiceUITsaUser);

  } catch(e){

    logger.error('Error while App Initializing' + e.message);

    expect.fail("Error while enter username" + e.message);

  }

});

When('I enter dosusername in username field in login page', async function() {

  try{

    expect(await elements["username"].isPresent()).to.be.true;

    await login.getVaultToken();

    await login.getDataFromVault();

    await  elements["username"].sendKeys(global.ServiceUIdosUser);

  } catch(e){

    logger.error('Error while App Initializing' + e.message);

    expect.fail("Error while enter username" + e.message);

  }

});

 

 

When(/^(?:I enter|I search) "([^"]*)" in "([^"]*)" (?:field|textbox)$/,  async function(value, object)  {

    try{

       

        if(object=="practice_name_field" && value!=='Albia'){

        var practice=faker.name.firstName();

        global.practicename=practice+" testpracticessss"

        await  elements["practice_name_field"].clear();

        await  elements["practice_name_field"].sendKeys(global.practicename);

       

        } else if (object == "practice_name_field" && value == "Albia") {

          var practiceAlbia = "Albia";

          //global.practicename=practice+" practice"

          await elements["practice_name_field"].clear();

          await elements["practice_name_field"].sendKeys(practiceAlbia);

 

  }

    else if(object=="Email_textbox"){

 

            var randomEmail = faker.internet.email();

            await  elements["Email_textbox"].clear();

            await  elements["Email_textbox"].sendKeys(randomEmail);

    }

    else if(object=="Facility_Name_Textbox"){

 

            global.facilityname=faker.name.firstName();

            await  elements["Facility_Name_Textbox"].clear();

            await  elements["Facility_Name_Textbox"].sendKeys(global.facilityname);

 

    }

    else if(object=="First_Name_textbox"){

      global.firstname=faker.name.firstName();

      await  elements["First_Name_textbox"].clear();

      await  elements["First_Name_textbox"].sendKeys(global.firstname);

    }

    else if(object=="Last_Name_textbox"){

      global.lastname=faker.name.firstName();

      await  elements["Last_Name_textbox"].clear();

      await  elements["Last_Name_textbox"].sendKeys(global.lastname);

    }

   

    else if(object=="new_device_serial_number"){

      browser.sleep(3000)

      await elements["new_device_serial_number"].clear();

      await elements["new_device_serial_number"].sendKeys(data[value]);

 

    }

    else if(value=='Aran_Eye_Care_hsdp_id')

    {

      const browserName= await utils.getbrowserName();

        await  elements[object].clear();

        await  elements[object].sendKeys(data[browserName+'_'+value]);

 

    }

    else if(value=='unique_device_serial_number_value')

    {

        await  elements[object].clear();

        await  elements[object].sendKeys(data["device_serial_number_value"]+await utils.getRandomInt(1,1000));

    }

    else{

 

        await  elements[object].clear();

        await  elements[object].sendKeys(data[value]);

   }

     

}catch(e){

             logger.error('Error while entering' + e.message);

             logger.error(object)

             expect.fail("Error while enter " + object +  e.message);

     }

   

});

//senario outline

When(/^I enter "([^"]*)" into "([^"]*)" (?:field|textbox)$/,  async function(value, object)  {

    try{

       

        await  elements[object].clear();

        await  elements[object].sendKeys(value);

   

     

}catch(e){

             logger.error('Error while entering' + e.message);

             logger.error(object)

             expect.fail("Error while enter " + object +  e.message);

     }

   

});

 

When(/^I click on "([^"]*)" (?:button|tab|link|practice|view more icon|option|dropdown|checkbox)$/, async function(locator) {

 

if(locator=="signin")  

{

 

    try{

 

        const result=await utils.checkIfElementEnabled(elements[locator]);

        const text=await utils.getTextFromTextBox(elements[locator]);

        browser.sleep(5000);

        await elements[locator].click();    

   

    } catch (e) {

        logger.error('Error while clicking' + e.message);

        logger.error(locator)

        expect.fail("Error while clicking " + locator +  e.message);

    }

  }

    else if(locator=="device_configuration_edit")  

{

 

    try{

 

       // browser.actions().dragAndDrop(elements[locator], {x: 0, y:100}).perform()

        await elements[locator].click();    

         

   

    } catch (e) {

        logger.error('Error while clicking' + e.message);

        logger.error(locator)

        expect.fail("Error while clicking " + locator +  e.message);

    }

  }

else if(locator=="edit_site_network"){

  try{

    browser.sleep(5000);

  // browser.executeScript('window.scrollTo(0,700)') ;

   await elements[locator].click();

  } catch (e) {

    logger.error('Error while clicking' + e.message);

    logger.error(locator)

    expect.fail("Error while clicking " + locator +  e.message);

   

}

   

  }

  else if(locator=="save_site_network"){

try{

 

    //browser.executeScript('window.scrollTo(0,700)') ;

    await elements[locator].click();

  } catch (e) {

    logger.error('Error while clicking' + e.message);

    logger.error(locator)

    expect.fail("Error while clicking " + locator +  e.message);

   

}

 

  }

  else if(locator=="new_remove"){

 

    browser.actions().dragAndDrop(elements[locator], {x: 0, y:100}).perform()

    await elements[locator].click();

 

  }

  else

{

    try{

        browser.sleep(5000);

        await elements[locator].click();

    } catch (e) {

        logger.error('Error while clicking' + e.message);

        logger.error(locator)

        expect.fail("Error while clicking " + locator +  e.message);

       

      }

 

}

});

 

When(/^I click "([^"]*)"$/,async function(object){

    try{

        browser.sleep(3000)

      // await browser.actions().mouseMove(elements[object]).click().perform();

      await elements[object].click();

        } catch (e) {

                logger.error('Error while selecting' + e.message);

                logger.error(object)

                expect.fail("Error while selecting " + object + e.message);

            }

    });

 

When(/^I clear "([^"]*)" (?:field|textbox)$/,async function(object){

try{

 

            browser.sleep(4000)

            await elements[object].sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));

            await elements[object].clear();

            await elements[object].click().sendKeys(' \b');

    } catch (e) {

            logger.error('Error while clearing' + e.message);

            logger.error(object)

            expect.fail("Error while clearing " + object + e.message);

    }

    });

   

When('I should get the current url',async function(){

        try{

            await browser.manage().timeouts().implicitlyWait(3000);

            global.url=await utils.getCurrentUrl();

        } catch (e) {

            logger.error('Error Message' + e.message);

            expect.fail("Error while getting url "  +  e.message);

        }

});

   

When('I copy the current url in new tab',async function(){

try{

            utils.switchToNewWindow();

            utils.appInitialization(global.url);

            await browser.manage().timeouts().implicitlyWait(3000);

            global.copiedurl=await utils.getCurrentUrl();

        } catch (e) {

            logger.error('Error while opening the tab' + e.message);

            expect.fail("Error while opening tab " +  e.message);

        }

});    

When('I enter FSE username in username field', async function() {

try{

 

      await login.getVaultToken();

      await login.getDataFromVault();

      elements["username"].sendKeys(global.ServiceUIFSEUser);

 

    } catch (e) {

      logger.error('Error while App Initializing' + e.message);

      expect.fail("Error while enter username " +  e.message);

    }

});

 

When('I enter FSE password in password field', async function() {

try{

 

      await login.getVaultToken();

      await login.getDataFromVault();

      elements["password"].sendKeys(global.ServiceUIFSEPassword);

 

    } catch(e){

      logger.error('Error while App Initializing' + e.message);

      expect.fail("Error while enter password " +  e.message);

    }

});

 

When('I enter TSE_username in username field', async function() {

    try{

      expect(await elements["username"].isPresent()).to.be.true;

      await login.getVaultToken();

      await login.getDataFromVault();

    await  elements["username"].sendKeys(global.ServiceUITSEUser);

    } catch(e){

      logger.error('Error while App Initializing' + e.message);

      expect.fail("Error while enter username " +  e.message);

    }

});

 

When('I enter TSE_password in password field', async function() {

    try{

      expect(await elements["password"].isPresent()).to.be.true;

 

      await elements["password"].sendKeys(global.ServiceUITSEPassword);

    } catch(e){

      logger.error('Error while App Initializing' + e.message);

      expect.fail("Error while enter password " + e.message);

    }

});

 

When(/^I search "([^"]*)" practice in practices page$/,async function(value){

    try{

      await elements["search"].clear();

      await elements["search"].sendKeys(data[value]);

    } catch (e) {

      logger.error('Error in searching' + e.message);

      expect.fail("Error while searching " +  e.message);

    }

  });  

 

  When(/^I search "([^"]*)" facility in facility page$/,async function(value){

    try{

      await elements["search_facility"].clear();

      await elements["search_facility"].sendKeys(data[value]);

    } catch (e) {

      logger.error('Error in searching' + e.message);

      expect.fail("Error while searching " +  e.message);

    }

  });

 

When(/^I click "([^"]*)" dropdown in practices page$/, async function(object){

 

    try{

      browser.sleep(5000);

      expect(await elements[object].isPresent()).to.be.true;

      await elements[object].click();

    } catch(e){

      logger.error('Error while App Initializing' + e.message);

      logger.error(object)

      expect.fail("Error while clicking " + object + e.message);

    }

  });  

 

When(/^I click random "([^"]*)" in practices page$/, async function(object){

 

    try{

 

      expect(await elements[object].isPresent()).to.be.true;

      elements[object].count().then(function (value) {

      elements[object].get(utils.getRandomInt(1, value)).click();

 

      });  

    } catch(e){

      logger.error('Error while App Initializing' + e.message);

      expect.fail("Error while clicking" +  e.message);

    }

  });

 

When('I search hsdid in  list page Devices', async function() {

    try{

      const expect = chai.expect;

      browser.sleep(2000);

      await elements["searchBoxOfDevices"].sendKeys(global.HSDPID);

    } catch(e){

      logger.error('Search Of Device' + e.message);

      expect.fail("Search Of Device" +  e.message);

    }

  });  

 

When(/^I select "([^"]*)" from the "([^"]*)" dropdown$/,async function(value,object){

 

      try{

        browser.sleep(3000)

        await elements[object].sendKeys(data[value]);

 

      }catch(e){

       

        logger.error('Error while selecting' + e.message);

        logger.error(object)

        expect.fail("Error while selecting" + object +  e.message);

    }

 

});

   

When(/^I select "([^"]*)" Radio button$/, async function (object) {

 

    try{

             await  elements[object].click();

 

 }catch(e){

 

          logger.error('Error while clicking' + e.message);

          logger.error(object)

          expect.fail("Error while clicking" + object + e.message);

 }

 });

 

 When(/^I search created facility$$/,async function(){

    try{

      await elements["search_facility"].sendKeys(global.facilityname);

    } catch (e) {

      logger.error('Error in searching' + e.message);

      expect.fail("Error while searching" +  e.message);

    }

  });

 

 When(/^I search created practice in practice page$/,async function(){

   try{

    await elements["search"].sendKeys(global.practicename);

   } catch (e) {

     logger.error('Error in searching' + e.message);

     expect.fail("Error while searching" +  e.message);

   }

 });

When('I click on  created practice',async function(){

 

  try{

   

    await element(by.xpath('//*[text()="'+ global.practicename +'"]')).click();

  } catch (e) {

    logger.error('Error in searching' + e.message);

    expect.fail("Error while searching" +  e.message);

  }

 

});

 

When('I enter startDate and endDate', async function () {

  try{

              const endDate=await utils.currentdate();

              const startDate=await utils.startDate();

              const start=global.date;

              await elements["startdatepicker"].click();

              await element(by.xpath('//*[@class="daycell currmonth tablesingleday ng-star-inserted" and @aria-label="Select day'+start+'"]')).click();

              await elements["enddatepicker"].click();

              await element(by.xpath('//*[@class="daycell currmonth tablesingleday ng-star-inserted" and @aria-label="Select day'+endDate+'"]')).click();




  } catch(e){

    logger.error('Error while entering start and end date' + e.message);

    expect.fail("Error while entering start and end date" +  e.message);

  }

});

When('I enter again startDate and endDate', async function () {

  try{

              const endDate=await utils.currentdate();

              const startDate=await utils.startDate();

              const start=global.date;

              await element(by.xpath('//*[@aria-label="Clear Date"]')).click();

              await elements["startdatepicker"].click();

              await element(by.xpath('//*[@class="daycell currmonth tablesingleday ng-star-inserted" and @aria-label="Select day'+start+'"]')).click();

              await elements["enddatepicker"].click();

              await element(by.xpath('//*[@class="daycell currmonth tablesingleday ng-star-inserted" and @aria-label="Select day'+endDate+'"]')).click();




  } catch(e){

    logger.error('Error while entering start and end date' + e.message);

    expect.fail("Error while entering start and end date" +  e.message);

  }

});

When(/^I get "([^"]*)"$/,async function(value){

  browser.sleep(3000)

  if(value=="practice_id")

  {

    try{

   

      //global.practiceId=await elements["practiceId_value"].getText();

      var spt=await utils.getCurrentUrl();

      var practiceurl=spt.split('practiceId=')[1].split('&');

      global.practiceId=practiceurl[0];

     

     

   } catch (e) {

     logger.error('Error in searching' + e.message);

     expect.fail("Error in searching" +  e.message);

   }

 

  }else if(value=="facility_id"){

 

  try{

   

    var spt=await utils.getCurrentUrl();

    var facilityurl=spt.split('facilityId=');

    global.facilityId=facilityurl[1];

 

  } catch (e) {

    logger.error('Error in searching facilityId' + e.message);

    expect.fail("Error in searching facilityId" +  e.message);

  }

  }else if(value=="practice_name"){

    try{

      var spt=await utils.getCurrentUrl();

      var practiceNameurl=spt.split('practiceName=')[1].split('&');

      global.practiceName=decodeURI(practiceNameurl[0]);

    }catch (e) {

      logger.error('Error in searching practiceName ' + e.message);

      expect.fail("Error in searching practiceName" +  e.message);

    }

  }

 

});

 

When('I enter startDate as current date',async function(){

 

  try{

    const Date=await utils.currentdate();

    await elements["startdatepicker"].click();

    await element.all(by.xpath('//*[@aria-label="Select day'+Date+'"]')).first().click();

 

} catch(e){

logger.error('Error while entering start and end date' + e.message);

expect.fail("Error in entering start and end date" +  e.message);

}

});

When('I enter startDate and endDate as less than current date',async function(){

  try{

    const startDate=await utils.startDate();

    const start=global.date;

    await element(by.xpath('//*[@aria-label="Clear Date"]')).click();

    await elements["startdatepicker"].click();

    await element(by.xpath('//*[@class="daycell currmonth tablesingleday ng-star-inserted" and @aria-label="Select day'+start+'"]')).click();

    await elements["enddatepicker"].click();

    await element(by.xpath('//*[@class="daycell currmonth tablesingleday ng-star-inserted" and @aria-label="Select day'+start+'"]')).click();

 

} catch(e){

logger.error('Error while entering start and end date' + e.message);

expect.fail("Error in entering start date and end date" +  e.message);

}



});

 

Then(/^I click "([^"]*)" for "([^"]*)" times$/,async function(element,time){

try{

   var i;

   for(i=0;i<time;i++)  {

 

  await  elements[element].click();

   }

 

}catch(e){

 

 logger.error('Error while clicking' + e.message);

 expect.fail("Error in clicking" +  e.message);

}

 

});

 

When('I click on created practice button', async function (){

 

    try{

      

      await element(by.xpath('//*[text()="'+ global.practicename +'"]')).click();

    } catch (e) {

      logger.error('Error in searching' + e.message);

      expect.fail("Error in searching" +  e.message);

    }

 

  });

 

  When('I click on created facility', async function (){

 

      try{

        

        await element(by.xpath('//*[text()="'+ global.facilityname +'"]')).click();

      } catch (e) {

        logger.error('Error in searching' + e.message);

        expect.fail("Error in clicking facility" +  e.message);

      }

   

    });

 

When(/^I select "([^"]*)"$/,async function(ele){

     

  try{

        var data1=data[ele]

       

        await element(by.cssContainingText('option', data1)).click();

     

      }catch(e){

     

       logger.error('Error while clicking' + e.message);

       expect.fail("Error in clicking" +  e.message);

      }

    });

 

When('I enter edgeId in configuresitenetwork', async function () {

 

  try {

    const randomEdgeId = "edgeId-" + await utils.getRandomInt(1, 100) + "-" + await utils.getRandomInt(1, 1000);

    await element(by.xpath("//*[@ng-reflect-name='edgeId']")).sendKeys(randomEdgeId);

  } catch (e) {

    logger.error('Error in searching' + e.message);

    expect.fail("Error in clicking facility" + e.message);

  }

 

});  

 

When('I enter deviceDisplayName in configuresitenetwork', async function () {

 

  try {

    const randomName = "Devicename-" + await utils.getRandomInt(1, 100) + "-" + await utils.getRandomInt(1, 1000);

    await element(by.xpath("//*[@formcontrolname='deviceDisplayName']")).sendKeys(randomName);

    global.displayname = randomName;

  } catch (e) {

    logger.error('Error in searching' + e.message);

    expect.fail("Error in clicking facility" + e.message);

  }

 

});

 

When('I enter serial Number value in device serial number field', async function () {

 

  try {

    element(by.xpath("//*[@formcontrolname='deviceSerialNumber']")).sendKeys(data["device_serial_number_value"] + await utils.getRandomInt(1, 100000));

  } catch (e) {

    logger.error('Error in searching' + e.message);

    expect.fail("Error in clicking facility" + e.message);

  }

});

When('I enter serial Number value in device serial number field in SiteNetwork Edit', async function () {

 

  try {

    element(by.xpath('//*[@id="addDeviceModal"]/div/div/form/div[1]/div[1]/div[3]/input')).sendKeys(data["Edit_INSiteNetwork_device_serial_number_value"] + await utils.getRandomInt(1, 100000));

  } catch (e) {

    logger.error('Error in searching' + e.message);

    expect.fail("Error in clicking facility" + e.message);

  }

});

When(/^I enter "([^"]*)" value in device serial number field in SiteNetwork Edit$/, async function (value) {

 

  try {

   

    element(by.xpath('//*[@placeholder="Device Serial Number"]')).sendKeys(data[value]);

    browser.sleep(500000)

    element(by.xpath('//*[@placeholder="Device Serial Number"]')).clear();

  } catch (e) {

    logger.error('Error in searching' + e.message);

    expect.fail("Error in clicking facility" + e.message);

  }

});