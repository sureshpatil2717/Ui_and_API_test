"use strict";
var log4js = require('log4js');
var logger = log4js.getLogger();
const { Given, Then, When } = require('cucumber');
const utils = require('../../Page_Objects/Generic_Methods/utils.js');
const login = require('../../Page_Objects/Generic_Methods/login.js');
const elements=require('../../Page_Objects/Elements_Contains/Elements.js');
const data = require('../../Test_Data/global_input.json');
var chai=require('chai');
chaiHttp = require('chai-http');
chai.use(chaiHttp);
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
const { protractor, browser } = require('protractor');
const path = require('path');
const yaml = require('js-yaml');
const fs   = require('fs');
const EC = protractor.ExpectedConditions;
const expect = chai.expect
var settime=utils.setTimeout();


Then(/^I should see "([^"]*)" (?:page|tabtext|dropdowntext|placeholder|titletext|text message|category|Rdbutton) is displayed$/,async function(object){
    try{
        browser.sleep(9000);
        const result=await utils.checkIfElementPresent(elements[object]);
      expect(result).to.equal(true);
    } catch (e) {
      logger.error('Error message' + e.message);
      logger.error(object)    
      expect.fail("Error while verifying" + object + e.message);  
    }
  });


Then(/^(?:I verify|Bydefault|I should see) "([^"]*)" (?:field|button|textbox) is (?:enabled|disabled)$/,async function(object){
    try{
        const result=await utils.checkIfElementEnabled(elements[object]);
        if(result == true){
            expect(result).to.be.true;
        }
        else if (result == false){
            expect(result).to.be.false;
        }
    }catch (e) {
        logger.error('Error while verifying' + e.message);
        logger.error(object)
        expect.fail("Error while verifying" + object + e.message);
        
    }
});


Then(/^I validate "([^"]*)" error message$/,async function(object){
    try{
        browser.sleep(3000)
        const expectedText=data[object];
        const Text=await utils.getTextFromTextBox(elements[object]);
        expect(Text).to.equal(expectedText);
    } catch (e) {
        logger.error('Error while validating' + e.message);
        logger.error(object)
        expect.fail("Error while verifying" + object + e.message);
        
    }
});

Then('I validate the current url with login page url',async function(){
    try{
        expect(global.copiedurl).to.equal(data["login_page_url"]);
    } catch (e) {
        logger.error('Error while validating' + e.message);
        expect.fail("Error while verifying"  + e.message);
        
    }
});


Then(/^I should see "([^"]*)" (?:tableHeaders|values|checkbox)$/, async function(object){
    try{
      expect(await elements[object].isPresent()).to.be.true;
    } catch(e){
      logger.error('Error while App Initializing' + e.message);
      logger.error(object)
      expect.fail("Error while verifying" + object + e.message);
      
    }
    });
Then(/^(?:I validate|I should see practice name) "([^"]*)" (?:text|error message|value) (?:is displayed|is added)$/, async function(object){
    try{
   
       expect(await elements[object].isPresent()).to.be.true;
       expect(await elements[object].getAttribute("value")).to.equal(global.practicename);
       
   } 
   catch(e){
     logger.error('Error while App Initializing' + e.message);
     logger.error(object)
     expect.fail("Error while verifying" + object + e.message);
     
    }
   }
);
Then(/^(?:I validate|I should see|I verify) "([^"]*)" (?:text|message|table Headers|button|Check box|textbox|error message|field|Radio Button|field Section|dropdown|value) (?:is displayed|is available|is added)$/, async function(object){
        if(object=="Aran_Eye_Care_hsdp_id"){
           try{
           const browserName= await utils.getbrowserName();
           expect(await elements[browserName+'_'+object].isPresent()).to.be.true;
            expect(await elements[browserName+'_'+object].getText()).to.equal(data[browserName+'_'+object]);
          
        } catch(e){
            logger.error('Error while App Initializing' + e.message);
            logger.error(object)
            expect.fail("Error while verifying" + object + e.message);
        }
         }
        else if(object=="Facility_inheritName"||object=="Address1_inherit"||object=="city_inherit"||object=="Country_inherit"||object=="ZipCode_inherit"){
         try{
        
            expect(await elements[object].isPresent()).to.be.true;
            expect(await elements[object].getAttribute("value")).to.equal(data[object]);
            
        
        } catch(e){
          logger.error('Error while App Initializing' + e.message);
          logger.error(object)
          expect.fail("Error while verifying" + object + e.message);
          
         }
        }
        else {
         try{
        
            expect(await elements[object].isPresent()).to.be.true;
            expect(await elements[object].getText()).to.equal(data[object]);
        
        } catch(e){
          logger.error('Error while App Initializing' + e.message);
          logger.error(object)
          expect.fail("Error while verifying" + object + e.message);
          
        }
      }
        });    

Then('I verify hsdp id and serial number and connectivity status and Last Message Received is present in device details page',async function(){
try{
        const currenttime=await utils.currentdate();
        const expect = chai.expect;
        expect(await element(by.xpath('//*[text()="'+ global.HSDPID +'"]')).isPresent() ).to.be.true;
            
            
    }catch(e){
            
    logger.error('Error while clicking' + e.message);
    expect.fail("Error while verifying" + e.message);
    }
});

Then('I verify device display name is present in device details page', async function () {
  try {
    const currenttime = await utils.currentdate();
    const expect = chai.expect;
    expect(await element(by.xpath('//*[text()="' + global.displayname + '"]')).isPresent()).to.be.true;

  } catch (e) {

    logger.error('Error while clicking' + e.message);
    expect.fail("Error while verifying" + e.message);
  }
});
            
            
Then('I verify hsdp id and serial number and connectivity status and Last Message Received is not present in device details page',async function(){
try{
        const currenttime=await utils.currentdate();
        const expect = chai.expect;
        expect(await element(by.xpath('//*[text()="'+ global.serialno +'"]')).isPresent() ).to.be.false;
        expect(await element(by.xpath('//*[text()="'+ global.HSDPID +'"]')).isPresent() ).to.be.false;
               
    }catch(e){
            
                      logger.error('Error while clicking' + e.message);
                      expect.fail("Error while verifying" + e.message);
            }
    });

    
Then(/^I should see the device registered through register list of device API$/, async function(){
try{
             
              expect(await utils.checkIfElementPresent(element(by.xpath("//*[text()='" + global.HSDPID + "']")))).to.be.true;
        
        }catch(e){
           logger.error('Error while App Initializing' + e.message);
           expect.fail("Error while verifying"  + e.message);
         }
        
}); 

Then(/^I should see Device Details of connectivity status of the Device$/,async function(){
  try{
 
  expect(await utils.checkIfElementPresent(elements["ConnectivityStatus"])).to.be.true;
    
}catch(e){
   logger.error('Error while App Initializing' + e.message);
   expect.fail("Error while verifying" + e.message);
 }
});

Then(/^I should see Device Display Name of the Device$/, async function () {
  try {

    expect(await utils.checkIfElementPresent(elements["deviceDisplayName"])).to.be.true;

  } catch (e) {
    logger.error('Error while App Initializing' + e.message);
    expect.fail("Error while verifying" + e.message);
  }
});

Then('I should not see the device registered through register list of device API',async function(){
try{
    
    expect(await utils.checkIfElementPresent(element(by.xpath("//*[text()='" + global.HSDPID + "']")))).to.be.false;
    
    }catch(e){
    
        logger.error('Error message' + e.message);
        expect.fail("Error while verifying"  + e.message);
       }
});   

Then(/^I verify Last Message Received$/,async function(){
  try{
    var lastmsg=global.CurrentTime+ " UTC";
    expect(await utils.checkIfElementPresent(element(by.xpath("//*[text()='" +lastmsg+ "']")))).to.be.true;
      
  }catch(e){
     logger.error('Error while App Initializing' + e.message);
     expect.fail("Error while verifying" + e.message);
   }
  });
Then(/^I should see "([^"]*)" (?:is displayed|popup is displayed|button should be displayed)$/, async function(object){

try{
        browser.sleep(2000);  
        expect(await elements[object].isPresent()).to.be.true;
        } catch(e){
          logger.error('Error while App Initializing' + e.message);
          logger.error(object)
          expect.fail("Error while verifying" + object + e.message);
          
        }
});


Then(/^I should not see "([^"]*)" is displayed$/, async function(object){
  if(object=="Aran_Eye_Care_hsdp_id"){
    try{
    const browserName= await utils.getbrowserName();
    expect(await elements[browserName+'_'+object].isPresent()).to.be.false;
    
    
  } catch(e){
      logger.error('Error while App Initializing' + e.message);
      logger.error(object)
      expect.fail("Error while verifying" + object + e.message);
    }
  }
  else{
        try{
          expect(await elements[object].isPresent()).to.be.false;
        } catch(e){
          logger.error('Error while App Initializing' + e.message);
          expect.fail("Error while verifying" + object + e.message);
          
        }
      }
});
  
 Then(/^I should not see "([^"]*)" in "([^"]*)" (?:textbox|field)$/,async function (value,locator) {
 try{
            const expect = chai.expect;
            const result= await elements[locator].getText();
            expect(result).to.not.equal(data[value]);
}catch(e){
                       logger.error('Error message' + e.message);
                       logger.error(locator)
                       expect.fail("Error while verifying" + locator + e.message);
 }
});

 Then(/^I should see "([^"]*)" in "([^"]*)" (?:textbox|field)$/,async function (value,locator) {
 try{
            const expect = chai.expect;
            const result= await elements[locator].getText();
            expect(result).to.equal(data[value]);

           }catch(e){
                       logger.error('Error message' + e.message);
                       logger.error(locator);
                       expect.fail("Error while verifying" + locator + e.message);
                   }

  });  

Then('I should see created practice in practice page',async function(){
    try{
        
         expect(await element(by.xpath('//*[text()="'+ global.practicename +'"]')).isPresent() ).to.be.true;
       } catch (e) {
         logger.error('Error in searching' + e.message);
         expect.fail("Error while searching"  + e.message);
       }
    
    });  

Then('I should see created facility in facility page',async function(){
      try{
          
           expect(await element(by.xpath('//*[text()="'+ global.facilityname +'"]')).isPresent() ).to.be.true;
         } catch (e) {
           logger.error('Error in searching' + e.message);
           expect.fail("Error while searching" +  e.message);
         }
      
      });     

  
Then(/^I should see Practice are displayed based on "([^"]*)"$/,async function(value){

          try{

            const expect = chai.expect;
            const result= await elements[value].getText();
            expect(result).to.equal(data[value]);


        }
        catch(e){
            logger.error('Error in searching the astrix' + e.message);
            expect.fail("Error while searching"  + e.message);
        }


         });         
Then(/^I should see "([^"]*)" "([^"]*)" messages are displayed$/,async function(value,locattor){
try{
            browser.sleep(7000)
            const expect = chai.expect;
            const val=data[value]
            const result= await elements["logmessages"].getText();
            expect(result.length).to.equal(val);


        }
        catch(e){
            logger.error('Error in searching the astrix' + e.message);
            expect.fail("Error while searching" +  e.message);

        }
      });
         
Then(/^I should see "([^"]*)" is displayed with "([^"]*)"$/,async function(locator,value){

  try{
    browser.sleep(5000)
    const expect = chai.expect;
    const val=data[value];
    
 
    expect(await element(by.xpath("//*[@ng-reflect-model='"+ val +"']")).isPresent() ).to.be.true;
  


}
catch(e){
    logger.error('Error in searching the value' + e.message);
    expect.fail("Error while searching"  + e.message);
  
}



});  

Then(/^I should see "([^"]*)" values upto "([^"]*)"$/,async function(element,value){

  try{
    browser.sleep(7000)
    const expect = chai.expect;
    const val=data[value]
    const result= await elements[element].getText();
    expect(result.length).to.equal(val);
   


}
catch(e){
    logger.error('Error in searching the ele' + e.message);
    expect.fail("Error while searching" + element + e.message);
}
}); 
Then('I verify ascending order of log messages',async function(){

  try {
    browser.sleep(10000)
    var i=0;
      var unsorted = await elements["logTime"].getText();
    var  sorted = unsorted;

      var ascend=sorted.sort(); //used for sorting ascending
      var descend=ascend.reverse();//descending sort
      for(i=0;i<=unsorted.length;i++){

            await  expect(descend[i]).to.equal(unsorted[i]);
 
          }
      
      
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while verifying" + e.message);
   }



});
Then('I verify descending order of log messages',async function(){
  try {
        browser.sleep(2000)
        var i=0;
        var unsorted = await elements["logTime"].getText();
        var  sorted = unsorted;
        var ascend=sorted.sort(); //used for sorting ascending
        for(i=0;i<=ascend.length;i++){
                await  expect(ascend[i]).to.equal(unsorted[i]);
              }
      
      
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while searching" + e.message);
   }

});	

Then(/^I should see "([^"]*)" is (?:enabled|disabled|field is disabled)$/,async function(object){
  try{
      const result=await utils.checkIfElementEnabled(elements[object]);
      if(result == true){
          expect(result).to.be.true;
      }
      else if (result == false){
          expect(result).to.be.false;
      }
  }catch (e) {
     logger.error('Error while verifying' + e.message);
     expect.fail("Error while verifying" + e.message);
  }
});
Then(/^I should see "([^"]*)" "([^"]*)" are displayed$/,async function(value,locator){
    try{
        browser.sleep(7000)
        const expect = chai.expect;
        const val=data[value]
        const result= await elements[locator].getText();
        expect(result.length).to.equal(val);
    }
    catch(e){
    logger.error('Error while displaying' + e.message);
    expect.fail("Error while displaying"  + e.message);
    }
});
Then(/^I verify ascending order of "([^"]*)"$/,async function(object){
    try {
        browser.sleep(10000)
        var i=0;
        var unsorted = await elements[object].getText();
        var  sorted = unsorted;
        var ascend=sorted.sort(); //used for sorting ascending
        var descend=ascend.reverse();//descending sort
        for(i=0;i<=unsorted.length;i++){
            await  expect(descend[i]).to.equal(unsorted[i]);
        }
    } catch(e){
    logger.error('Error in searching' + e.message);
    expect.fail("Error while verifying" + e.message);
    }
});
Then(/^I verify descending order of "([^"]*)"$/,async function(object){
    try {
        browser.sleep(2000)
        var i=0;
        var unsorted = await elements[object].getText();
        var  sorted = unsorted;
        var ascend=sorted.sort(); //used for sorting ascending
        for(i=0;i<=ascend.length;i++){
            await  expect(ascend[i]).to.equal(unsorted[i]);
         }
         } catch(e){
            logger.error('Error in searching' + e.message);
            expect.fail("Error while searching" + e.message);
         }
});
Then(/^I should not see Practice are displayed based on "([^"]*)"$/,async function(value){
    try{
            const expect = chai.expect;
            const result= await elements[value].getText();
            expect(result).to.not.equal(data[value]);
     }
        catch(e){
            logger.error('Error in searching the astrix' + e.message);
            expect.fail("Error while searching" + e.message);
        }
});
Then('I should see logged in user name',async function(){ 
  try {
    element(by.xpath('//*[@id="exampleModal"]/div/div/div[2]/div/div[2]/table/tbody/tr[1]/td[1]/div')).getText().then(function (text) {
		const str=text; 
      const n = str.includes("sureshadmin@yopmail.com");
      const expect = chai.expect;
      expect(n).to.equal(true);
    })
      
      
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while searching" + e.message);
   }

});
Then('I should see Timestamp',async function(){ 
  try {
    element(by.xpath('//*[@id="exampleModal"]/div/div/div[2]/div/div[2]/table/tbody/tr[1]/td[1]/div')).getText().then(function (text) {
      const str=text;  
      const n = str.includes("ago");
      const expect = chai.expect;
      expect(n).to.equal(true);
    })
        
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while searching" + e.message);
   }

});


Then('Verify Toggale button is set to Local by default',async function(){ 
  try {
    browser.sleep(1000)
    const Result= await element(by.className("toggle-button-text-off")).getText();
     expect(Result).to.equal('Local');
        
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while searching" + e.message);
   }

});
Then('I should see UTC time stamp in time feild',async function(){ 
  try {
    element(by.xpath("//table/tbody/tr/td[2]")).getText().then(function (text) {
      const str=text;
      const n = str.includes("UTC");
      const expect = chai.expect;
      expect(n).to.equal(true);
    })
        
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while searching" + e.message);
   }

});
Then('I should see Local time stamp in time feild',async function(){ 
  try {
    browser.sleep(3000);
    element(by.xpath("//table/tbody/tr/td[2]")).getText().then(function (text) {
      const str=text;
      const n = str.includes("UTC");
      
      const expect = chai.expect;
      expect(n).to.equal(false);
    })
        
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while searching" + e.message);
   }

});
Then('I should see Local time stamp in LastMessageReceived feild',async function(){ 
  try {
    browser.sleep(3000);
    element(by.xpath("//table/tbody/tr/td[8]")).getText().then(function (text) {
      const str=text;
      const n = str.includes("UTC");
      const expect = chai.expect;
      expect(n).to.equal(false);
    })
        
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while searching" + e.message);
   }

});
Then('I should see UTC time stamp in LastMessageReceived feild',async function(){ 
  try {
    browser.sleep(3000);
    element(by.xpath("//table/tbody/tr/td[8]")).getText().then(function (text) {
      const str=text;
      const n = str.includes("UTC");
      console.log(n);
      const expect = chai.expect;
      expect(n).to.equal(true);
    })
        
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while searching" + e.message);
   }

});
Then('I should see UTC time stamp in LastMessageReceived feilds',async function(){ 
  try {
    browser.sleep(3000);
    element(by.xpath("//table/tbody/tr/td[6]")).getText().then(function (text) {
      const str=text;
      const n = str.includes("UTC");
      console.log(n);
      const expect = chai.expect;
      expect(n).to.equal(true);
    })
        
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while searching" + e.message);
   }

});

Then('I should see Local time stamp in LastMessageReceived feilds',async function(){ 
  try {
    browser.sleep(3000);
    element(by.xpath("//table/tbody/tr/td[6]")).getText().then(function (text) {
      const str=text;
      const n = str.includes("UTC");
      console.log(n);
      const expect = chai.expect;
      expect(n).to.equal(false);
    })
        
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while searching" + e.message);
   }

});
Then('I verify ascending order of TranscationID',async function(){

  try {
    browser.sleep(10000)
    var i=0;
      var unsorted = await elements["Transcationid"].getText();
    var  sorted = unsorted;

      var ascend=sorted.sort(); //used for sorting ascending
      var descend=ascend.reverse();//descending sort
      for(i=0;i<=unsorted.length;i++){

            await  expect(descend[i]).to.equal(unsorted[i]);
 
          }
      
      
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while verifying" + e.message);
   }



});
Then('I verify descending order of TranscationID',async function(){
  try {
        browser.sleep(2000)
        var i=0;
        var unsorted = await elements["Transcationid"].getText();
        var  sorted = unsorted;
        var ascend=sorted.sort(); //used for sorting ascending
        for(i=0;i<=ascend.length;i++){
                await  expect(ascend[i]).to.equal(unsorted[i]);
              }
      
      
   } catch(e){
          logger.error('Error in searching' + e.message);
          expect.fail("Error while searching" + e.message);
   }

});	
Then(/^Verify By default "([^"]*)" is selected from the "([^"]*)" dropdown$/,async function (value,locator) {
  try{
    if(locator=="All_Category"){
  const expect = chai.expect;

  await element(by.xpath('//*[@id="exampleModal"]/div/div/div[2]/div/div[1]/div[2]/div/select')).getAttribute("value").then(function (text) {
    
 
  expect(text).to.equal(data[value]);
    

   }) 
  }
  else if(locator=="please_selectCategory"){
    const expect = chai.expect;
  
    await element(by.xpath('//*[@class="form-control addNoteSelect ng-untouched ng-pristine ng-valid"]')).getAttribute("value").then(function (text) {
    expect(text).to.equal(data[value]);
  })

  }

 
   }catch(e){
  logger.error('Error message' + e.message);
  logger.error(locator)
  expect.fail("Error while verifying" + locator + e.message);
   }
   });
   
   
   Then('I wait for 30 seconds',async function() {
  try{
      await browser.sleep(120000)
  }
  catch (e) {
      logger.error('Cannot wait' + e.message);
      expect.fail("Cannot wait" + e.message);
  }
});

Then('I wait for 20 seconds',async function() {
  try{
      await browser.sleep(30000)
  }
  catch (e) {
      logger.error('Cannot wait' + e.message);
      expect.fail("Cannot wait" + e.message);
  }
});

Then('I wait for 40 seconds',async function() {
  try{
      await browser.sleep(180000)
  }
  catch (e) {
      logger.error('Cannot wait' + e.message);
      expect.fail("Cannot wait" + e.message);
  }
});
