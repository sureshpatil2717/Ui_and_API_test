const log4js = require('log4js');
log4js.configure({
    appenders: {
        everything: {
            type: 'file',
            filename:'../testLogs/Execution_Logs_Consolidated.log',
            maxLogSize: 10485760,
            backups: 3,
            compress: true
        }      
    },
    categories: {
        default: {
            appenders: ['everything'],
            level: 'debug'
        }
    }
})
exports.config = {
    numOfChars: 6,
   // directConnect: true,
    //baseURL: iamUrl,
    ignoreUncaughtExceptions: true,
    getPageTimeout: 60000,
    allScriptsTimeout: 60000,
    framework: 'custom',
    frameworkPath: require.resolve('protractor-cucumber-framework'),
    
    specs: [
       //'Specs/Features/*.feature',
 
 'Specs/Features/userStories/526_createSitenetwork.feature',
       'Specs/Features/userStories/527_view_log_messages.feature',
    'Specs/Features/userStories/528_listofLogicalDevices.feature',
    'Specs/Features/userStories/1458_viewSiteNetwork.feature',	
    'Specs/Features/userStories/26813_Able_to_display_DML_and_Pentacam_devices_as_part_of_device_groups_as_part_of_corresponding_device_groups.feature', 
    'Specs/Features/userStories/4712.facilityManagment.feature',
	  'Specs/Features/userStories/1459_editSiteNetwork.feature',
//    'Specs/Features/userStories/5732_practiceAndFacilityCreationUpdated.feature',
//    'Specs/Features/userStories/8564_digitalOperationSupport.feature',
       'Specs/Features/userStories/1254_connectivicty_status.feature',
       'Specs/Features/userStories/1256_FieldServiceEngineerAccess.feature',
       'Specs/Features/userStories/1462_Display_practices_based_on_the_region_settings.feature',
       'Specs/Features/userStories/1466_DisplayDetailsofSelectedDevice.feature',
     'Specs/Features/userStories/2163_Technical_Support_Engineer_Role.feature',
    
      'Specs/Features/userStories/20677_DicomConfigurationFor_DiagnosticDevice.feature',
      
	'Specs/Features/userStories/28707_User_able_to_view_the_attachment_links_and_download_the_Notes_attachment.feature',
    'Specs/Features/userStories/29248_Able_to_Display_Note_Option_For_User_in_All_Practice_and_Facilityconfiguration_Pages.feature',
//  'Specs/Features/userStories/15431_Create_Facility_InheritPractice.feature',
     'Specs/Features/userStories/14891_EdgeIdInSiteNetworkFacility.feature',
     'Specs/Features/userStories/20268_listDevicesInPractice.feature',
      'Specs/Features/userStories/16983_UI_Page_to_support_adding_notes.feature',
     'Specs/Features/userStories/915_loginScreenValidation.feature',
	 'Specs/Features/userStories/32256_ability_to_suspend_a_practice.feature',
     'Specs/Features/userStories/28708_Able_to_view_the_Transaction_id_for_a_given_log_message.feature',
    //  'Specs/Features/userStories/32262_ability_to_identify_practice_as_testpractice.feature',
       // features
      	
      'Specs/Features/feature/245_DisplayListofRegisteredDevices.feature',
//   'Specs/Features/feature/5316_PracticeandFacilityManagement.feature',
    'Specs/Features/feature/243_ManagetheSiteNetworkConfiguration.feature',
     'Specs/Features/feature/1255_Differentroleworkflow.feature',
 'Specs/Features/userStories/32513_Abilitytoremove_deploy.feature',
//  'Specs/Features/epic/242_ServiceAppUserInterface.feature',
 
//  'Specs/Features/userStories/32257_ability_to_suspend_restore.feature',
//  'Specs/Features/userStories/36217_Alcon_digital_select_one_or_more_practices_associate_button.feature',
 'Specs/Features/userStories/29467_User_able_view_and_configure_NGENUITY_Device_type.feature',
//  'Specs/Features/userStories/36184_To_create_practice_of_type_ASC.feature',
//  'Specs/Features/userStories/32254_update_of_ORA_when_practice_details_are_changed.feature',

 
//  'Specs/Features/userStories/38960_merge_pilot_practice_from_pilot_ORA_to_master_ORA.feature',
 'Specs/Features/userStories/38959_ASC_association_should_happen.feature',
//  'Specs/Features/userStories/39115_Facility_button_removal_in_dhs_and_ora.feature',
//  'Specs/Features/userStories/39137_suucees.feature',
 'Specs/Features/userStories/32221_softdelete_device_from_iicportal.feature',
 'Specs/Features/userStories/32222_Ability_to_auto_update_the_site_network_configuration_for_deleting_devices.feature',
 'Specs/Features/userStories/42296_one_ASC_to_multiple_clinics.feature',
      //    //epic
     
          ],

    cucumberOpts: {
        require: [
            'Specs/Step_Definitions/*.js',
            'config/cucumber.conf.js'
        ],
        // tags: true,
        format: 'json:Reports/rep.json',
        profile: false,
        'no-source': true,
        //defaultTimeout: 200000,
        launchReport: true,
        tags: ['@UTC_****** and @S_3 or ~@skip']
    },

    multiCapabilities: [

       {
        'browserName': 'chrome',
        chromeOptions: {
                  args: ["no-sandbox","--headless", "--disable-gpu", "--window-size=1280x1024"]
                   },
        
      }],

    plugins: [{
        package: require.resolve('protractor-multiple-cucumber-html-reporter-plugin'),
        options: {
            automaticallyGenerateReport: true,
            removeExistingJsonReportFile: true,
            ignoreUncaughtExceptions: true,
            reportName: 'HSDP Service_UI Test Report',
            pageFooter: '<div><p>Tested by Protractor</p></div>',
            pageTitle: 'HSDP Service_UI Automation Report',
            customData: {
                title: 'Execution Information',
                data: [{
                    label: 'Project',
                    value: 'HSDP Service_UI'
                },
                    {
                        label: 'Release',
                        value: '1.1.0.0'
                    },
                    {
                        label: 'Tester',
                        value: 'Protractor'
                    }
                ]
            },
            openReportInBrowser: true,
            removeOriginalJsonReportFile: true
        }
    }],

};